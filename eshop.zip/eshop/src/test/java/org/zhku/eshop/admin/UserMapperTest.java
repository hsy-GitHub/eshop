package org.zhku.eshop.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EUserMapper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserMapperTest {
    @Autowired
    EUserMapper eUserMapper;

    @Test
    public void testSelectByUserIdAndPasswordAndRole(){
        EUser eUser = eUserMapper.selectByUserIdAndPasswordAndRole("admin", "123456", 2);
        System.out.println();
    }

    @Test
    public void testSearchUserByRoleLimit(){
        //完整查看
        List<EUser> hello = eUserMapper.selectLikeUserIdByRoleLimit("hello", "1", 0, 100);
        List<EUser> hello1 = eUserMapper.selectLikeUserIdByRoleLimit("hello", "2", 0, 100);
        List<EUser> eUsers = eUserMapper.selectLikeUserIdByRoleLimit(null, "1", 0, 100);
        List<EUser> eUsers1 = eUserMapper.selectLikeUserIdByRoleLimit(null, null, 0, 100);
        System.out.println();
        //分页测试
        List<EUser> hello3 = eUserMapper.selectLikeUserIdByRoleLimit("hello", "1", 0, 5);
        List<EUser> hello4 = eUserMapper.selectLikeUserIdByRoleLimit("hello", "2", 0, 5);
        List<EUser> eUsers3 = eUserMapper.selectLikeUserIdByRoleLimit(null, "1", 0, 5);
        List<EUser> eUsers4 = eUserMapper.selectLikeUserIdByRoleLimit(null, null, 0, 5);
        System.out.println();
    }

    @Test
    public void testCountByRole(){
        System.out.println(eUserMapper.countLikeUserIdByRole("hello","1"));
        System.out.println(eUserMapper.countLikeUserIdByRole("hello","2"));
        System.out.println(eUserMapper.countLikeUserIdByRole(null,"1"));
        System.out.println(eUserMapper.countLikeUserIdByRole(null,null));
    }

    @Test
    public void testInsert()throws Exception{
        long email = 777777200l;
        long phone = 1581582000l;
        for(int i=0;i<20;++i){
            EUser eUser = new EUser();
            eUser.setUserId("nohello"+i);
            eUser.setPassWord("123456");
            eUser.setName("nohello"+i);
            eUser.setProvince("广东省");
            eUser.setCity("广州");
            eUser.setSex(1);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
            eUser.setBirthday(date);

            eUser.setEmail(email+"@qq.com");
            email++;
            eUser.setPhone(String.valueOf(phone));
            eUser.setAddress("白云山区");
            eUser.setRole(1);
            eUser.setCreateDate(date);
            eUser.setActiveStatus(1);
            eUserMapper.insert(eUser);
        }
    }
}
