package org.zhku.eshop.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.mapper.EGoodsTypeMapper;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EGoodsTypeMapperTest {
    @Autowired
    private EGoodsTypeMapper mapper;

    @Test
    public void testSelectByCodeEqualFour(){
        List<EGoodsType> eGoodsTypes = mapper.selectByCodeEqualFour();
        System.out.println();
    }

    @Test
    public void testSelectByPreCode(){
        List<EGoodsType> eGoodsTypes = mapper.selectByPreCode("0001");
        List<EGoodsType> eGoodsTypes1 = mapper.selectByPreCode("0002");
        List<EGoodsType> eGoodsTypes2 = mapper.selectByPreCode("0003");
        System.out.println();
    }

    @Test
    public void testSelectMaxByPreCode(){
        System.out.println(mapper.selectMaxByPreCode("0001"));
    }

    @Test
    public void testSelectMaxPreCode(){
        System.out.println(mapper.selectMaxPreCode());
    }
}
