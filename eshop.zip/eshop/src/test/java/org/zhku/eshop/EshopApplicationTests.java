package org.zhku.eshop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.EUserMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EshopApplicationTests {
    @Autowired
    EUserMapper eUserMapper;

    @Autowired
    EGoodsMapper eGoodsMapper;
    @Test
    public void contextLoads() {
        EUser eUser = eUserMapper.selectByPrimaryKey(1);
        EGoods eGoods = eGoodsMapper.selectByPrimaryKey(1);
        System.out.println("123");
    }

}
