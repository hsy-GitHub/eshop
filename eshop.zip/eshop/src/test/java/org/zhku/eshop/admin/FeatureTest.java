package org.zhku.eshop.admin;

import org.junit.Test;
import org.springframework.util.FileCopyUtils;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.util.AdminUtil;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FeatureTest {
    @Test
    public void testGeneratePictureName(){
        System.out.println(AdminUtil.getPirtureName("00010002",new Date(),1,"jpg"));
    }

    @Test
    public void testImageCopy() throws IOException {
//        AdminUtil.copyPir();
        File file = new File(ClassLoader.getSystemResource("org/zhku").getPath(), "100.jpg");
//        file.createNewFile();
                System.out.println(file.getAbsolutePath());

        final InputStream in = ClassLoader.getSystemResourceAsStream("cp.jpg");
        OutputStream out = new FileOutputStream(file);
        FileCopyUtils.copy(in,out);
//        final URL systemResource = ;
//        System.out.println(systemResource.getPath());

    }

    @Test
    public void test(){
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        System.out.println(simpleDateFormat.format(new Date()));
//       Files.getE
    }

    @Test
    public void testDateFormat() throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.println(simpleDateFormat.format(new Date()));
        System.out.println(simpleDateFormat.parse("2016-02-03"));
        System.out.println();
    }
}
