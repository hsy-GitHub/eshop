package org.zhku.eshop.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderDetail;
import org.zhku.eshop.mapper.EOrderMapper;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EOrderMapperTest {
    @Autowired
    EOrderMapper mapper;

    @Test
    public void testSelectByUserIdPageable(){
        List<EOrder> eOrders = mapper.selectByUserIdPageable(2, 0, 1);
        List<EOrder> eOrders1 = mapper.selectByUserIdPageable(2, 0, 5);
        System.out.println();
    }

    @Test
    public void testSelectByTradingStatusEqualNull(){
        List<EOrder> eOrders = mapper.selectByTradingStatusEqualNullAndAlipayEqualOne(0,5);
        System.out.println();
    }

    @Test
    public void testCountByTradingStatusEqualNullAndAlipayEqualOne(){
        System.out.println(mapper.countByTradingStatusEqualNullAndAlipayEqualOne());
    }

    @Test
    public void testCountByTradingStatusEqualZero(){
        System.out.println(mapper.countByTradingStatusEqualZero());
    }

    @Test
    public void testSelectByTradingStatusEqualZero(){
        List<EOrder> eOrders = mapper.selectByTradingStatusEqualZero(1, 10);
        List<EOrder> eOrders1 = mapper.selectByTradingStatusEqualZero(1, 3);
        System.out.println();
    }

    @Test
    public void testCountByTradingStatusEqualOne(){
        System.out.println(mapper.countByTradingStatusEqualOne());
    }

    @Test
    public void testSelectByTradingStatusEqualOne(){
        List<EOrder> eOrders1 = mapper.selectByTradingStatusEqualOne(1, 1);
        List<EOrder> eOrders2 = mapper.selectByTradingStatusEqualOne(1, 2);
        System.out.println();
    }
    
    @Test
    public void testSelectByTradingStatus(){
        List<EOrderDetail> eOrderDetails = mapper.selectByTradingStatus(null, 0, 10,null);
        List<EOrderDetail> eOrderDetails1 = mapper.selectByTradingStatus("0", 0, 10,"chc");
        List<EOrderDetail> eOrderDetails2 = mapper.selectByTradingStatus("1", 0, 10,null);
        System.out.println();
    }

    @Test
    public void testCountByTradingStatus(){
        System.out.println(mapper.countByTradingStatus(null,null));
        System.out.println(mapper.countByTradingStatus("0",null));
        System.out.println(mapper.countByTradingStatus("1",null));
    }
}
