package org.zhku.eshop.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.service.admin.OrderService;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderServiceTest {
    @Autowired
    private OrderService service;

    @Test
    public void testGetOrdersByUserIdPageable(){
//        List<EOrder> orderNeededSent = service.getOrderNeededSent(0,5);
        System.out.println();
    }
}
