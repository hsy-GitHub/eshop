package org.zhku.eshop.admin;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EOrderItemDetail;
import org.zhku.eshop.mapper.EOrderItemMapper;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EOrderItemMapperTest {
    @Autowired
    EOrderItemMapper mapper;

    @Test
    public void testSelectOrderDetailByOrderId(){
        List<EOrderItemDetail> eOrderItemDetails = mapper.selectOrderDetailByOrderId(1);
        List<EOrderItemDetail> eOrderItemDetails1 = mapper.selectOrderDetailByOrderId(2);
        List<EOrderItemDetail> eOrderItemDetails2 = mapper.selectOrderDetailByOrderId(3);
        List<EOrderItemDetail> eOrderItemDetails3 = mapper.selectOrderDetailByOrderId(4);
        List<EOrderItemDetail> eOrderItemDetails4 = mapper.selectOrderDetailByOrderId(5);
        System.out.println();
    }
}
