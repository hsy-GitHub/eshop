package org.zhku.eshop.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.mapper.EGoodsMapper;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EGoodsMapperTest {
    @Autowired
    EGoodsMapper mapper;

    @Test
    public void testSelectByTitleAndBrandAndTypeCodePageable(){
        //null或者空串填充测试
        List<EGoods> eGoods = mapper.selectByTitleAndBrandAndTypeCodePageable(null,null,null,0,10);
        List<EGoods> eGoods1 = mapper.selectByTitleAndBrandAndTypeCodePageable("","","",0,10);

        //单个参数查询
        List<EGoods> eGoods2 = mapper.selectByTitleAndBrandAndTypeCodePageable("苹果","","",0,10);
        List<EGoods> eGoods3 = mapper.selectByTitleAndBrandAndTypeCodePageable("","松下","",0,10);
        List<EGoods> eGoods4 = mapper.selectByTitleAndBrandAndTypeCodePageable("","","00010001",0,10);

        //多条件查询测试
        List<EGoods> eGoods5 = mapper.selectByTitleAndBrandAndTypeCodePageable("苹果","电信","",0,10);
        List<EGoods> eGoods6 = mapper.selectByTitleAndBrandAndTypeCodePageable("Galaxy","","00010007",0,10);
        List<EGoods> eGoods7 = mapper.selectByTitleAndBrandAndTypeCodePageable("","三星","00010001",0,10);

        System.out.println();
    }

    @Test
    public void testSelectCountByTitleAndBrandAndTypeCodePageable(){
        List<EGoods> eGoods = mapper.selectByTitleAndBrandAndTypeCodePageable("苹果","电信","",0,3);
        int total = mapper.selectCountByTitleAndBrandAndTypeCodePageable("苹果", "电信", "");
        System.out.println();
    }

    @Test
    public void testCountByTypeCode(){
        System.out.println(mapper.countByTypeCode("00010001"));
    }
}
