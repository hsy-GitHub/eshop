package org.zhku.eshop.service.client;


import java.util.List;

import org.zhku.eshop.entity.EUser;

public interface ClientUserService {

    public int addUser(EUser user);

    public void deleteUsers(List<Integer>ids);

	public EUser checkUserbyMail(String loginId, String password);

	public EUser checkUserbyUserID(String loginId, String password);

	public EUser checkUserbyPhone(String loginId, String password);

	public EUser selectByPrimaryKey(int id);

}
