package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.mapper.EGoodsMapper;

import java.util.List;

@Service
public class GoodsService {
    @Autowired
    private EGoodsMapper mapper;

    public ResponseResult<EGoods> getGoodsByTitleAndBrandNameAndTypeCodePageable(String title, String brandName, String typeCode, int pageNum, int pageSize ){
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        List<EGoods> eGoods = mapper.selectByTitleAndBrandAndTypeCodePageable(title, brandName, typeCode, start, pageSize);
        int total = mapper.selectCountByTitleAndBrandAndTypeCodePageable(title, brandName, typeCode);
        return new ResponseResult<EGoods>(eGoods,total);
    }


    public boolean add(EGoods goods){
        goods.setId(null);
        mapper.insert(goods);
        return true;
    }

    public boolean update(EGoods goods){
        int flag = mapper.updateByPrimaryKey(goods);
        return flag==1?true:false;
    }

    public boolean delete(int id){
        int flag = mapper.deleteByPrimaryKey(id);
        return flag==1?true:false;
    }

    public int getPosition(String typeCode) {
        return mapper.countByTypeCode(typeCode)+1;
    }

    public boolean deleteGoods(List<Integer> ids) {
        ids.forEach(id->mapper.deleteByPrimaryKey(id));
        return true;
    }

    public EGoods getById(int id) {
        return mapper.selectByPrimaryKey(id);
    }


	public List<EGoods> getGoodsList() {
		return mapper.selectAllGoods();
	}
}
