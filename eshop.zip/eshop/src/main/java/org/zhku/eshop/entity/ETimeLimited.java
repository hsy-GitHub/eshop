package org.zhku.eshop.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ETimeLimited {
    private Integer id;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date limitDate;

    private Integer goodsId;

    private Integer isEnd;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getLimitDate() {
        return limitDate;
    }

    public void setLimitDate(Date limitDate) {
        this.limitDate = limitDate;
    }

    public Integer getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getIsEnd() {
        return isEnd;
    }

    public void setIsEnd(Integer isEnd) {
        this.isEnd = isEnd;
    }
}