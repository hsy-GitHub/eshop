package org.zhku.eshop.service.client.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderItem;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EOrderItemMapper;
import org.zhku.eshop.mapper.EOrderMapper;
import org.zhku.eshop.mapper.EUserMapper;
import org.zhku.eshop.service.client.ClientOrderService;
import org.zhku.eshop.service.client.ClientUserService;

import java.util.Date;
import java.util.List;

@Service
public class ClientOrderServiceImpl implements ClientOrderService {

    @Autowired(required = false)
    EOrderMapper eOrderMapper;
    
    @Autowired(required = false)
    EOrderItemMapper eOrderItemMapper;

	@Override
	public List<EOrder> selectOrderByUserId(String loginId) {
		
		return eOrderMapper.selectOrderByUserId(loginId);
	}

	@Override
	public List<EOrderItem> selectGoodsIdByOrderId(int orderId) {
		return eOrderItemMapper.selectGoodsIdByOrderId(orderId);
	}

	@Override
	public int updateTradingStatus(Integer orderId) {
		return eOrderMapper.updateTradingStatus(orderId);
	}

	@Override
	public int insertOrderBackId(EOrder order) {
		return eOrderMapper.insertOrderBackId(order);
	}

	@Override
	public int insertOrderItem(EOrderItem orderItem) {
		return eOrderItemMapper.insert(orderItem);
	}

	@Override
	public int updateOrderById(EOrder order) {
		
		return eOrderMapper.updateByPrimaryKeySelective(order);
	}

	@Override
	public int deleteByPrimaryKey(int orderId) {
		return eOrderMapper.deleteByPrimaryKey(orderId);
	}

	@Override
	public int deleteItemByOrderId(int orderId) {
		return eOrderItemMapper.deleteItemByOrderId(orderId);
	}

	

    

   
    
}
