package org.zhku.eshop.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.zhku.eshop.entity.EShopCartVO;

public class CookieUtil {
	/**
	 * 返回购物车的Cookie
	 * @param request
	 * @param loginId
	 * @return
	 */
	public Cookie getShopCartCookie(HttpServletRequest request) {
		int loginId_int =0;
		if(request.getSession().getAttribute("loginId")!=null) {
			loginId_int = (int) request.getSession().getAttribute("loginId");//因为int不能为null，默认为0
		}else {
			return null;
		}
		String loginId="";
//		System.out.println("###"+loginId);
		loginId=String.valueOf(loginId_int);//这样做之前只需要控制loginId_int不为null
		if("".equals(loginId)&&loginId==null) {
			return null;	//用作ajax的返回信息
		}else {
			Cookie[] cookies = request.getCookies();
	        Cookie userCartCookie = null;
	        String userCartCookieName = loginId+"Cart";//登录的用户的购物车的名字为用户id+'Cart'
	        for (Cookie cookie : cookies) {
	            if (userCartCookieName.equals(cookie.getName())) { //获取购物车cookie
	            	userCartCookie = cookie;
	            	return userCartCookie;
	            }
	        }
		}
		return null;
	}
	
	/**
	 * 得到某用户的购物车中一共有几条记录
	 * @throws UnsupportedEncodingException 
	 */
	public int getShopCartNum(HttpServletRequest request) throws UnsupportedEncodingException {
		Cookie userCartCookie= getShopCartCookie(request);
		int num=0;
		 if (userCartCookie != null) {
			 // 获取cookie中String类型的value
	           String  cartValue = URLDecoder.decode(userCartCookie.getValue(), "utf-8");//从cookie获取购物车
	            // 判断value是否为空或者""字符串，cookie里存id|num#id|num
	            if (cartValue != null && !"".equals(cartValue)) {
	            	//把数据取出来
	            	String[] idNumArr=cartValue.split("#");
	            	num = idNumArr.length;
	            }
		 }
		return num;	
	}
	/**
	 * 查找在cookie上有没有记录用户的登录信息
	 * @param request
	 * @return
	 */
	public String[] getLoginIdAndPsw(HttpServletRequest request){
		//判断是否在cookie中有记住用户登录的痕迹
		String loginId = "";
		String password = "";
		//获取当前站点的所有Cookie
		Cookie[] cookies = request.getCookies();
		if(cookies!=null) {
		    for (int i = 0; i < cookies.length; i++) {//对cookies中的数据进行遍历，找到用户名、密码的数据
		    	if ("loginId".equals(cookies[i].getName())) {
		    		loginId = cookies[i].getValue();
		    	}
		    	if ("passWord".equals(cookies[i].getName())) {
		    		password = cookies[i].getValue();
		    	}
			}
		}
		String[] loginIdAndPsw = new String[2];
		loginIdAndPsw[0] = loginId;
		loginIdAndPsw[1] = password;
		return loginIdAndPsw;
	}
	
	/**
	 * 注销cookie
	 * @param request
	 * @return
	 */
	public int Logout(HttpServletRequest request,HttpServletResponse response) {
		//注销时要删除session和cookie里的数据	
		Enumeration em = request.getSession().getAttributeNames();
		  while(em.hasMoreElements()){
		   request.getSession().removeAttribute(em.nextElement().toString());
		  }
		
		//获取cookie
		Cookie[] cookies = request.getCookies();
        for (Cookie cookie : cookies) {
        	cookie.setMaxAge(0);
        	response.addCookie(cookie);
        }
		return 0;	
	}
	
	
}
