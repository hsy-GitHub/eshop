package org.zhku.eshop.service.client.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.EGoodsTypeMapper;
import org.zhku.eshop.mapper.ETimeLimitedMapper;
import org.zhku.eshop.mapper.EUserMapper;
import org.zhku.eshop.service.client.ClientGoodsService;
import org.zhku.eshop.service.client.ClientUserService;

import java.util.Date;
import java.util.List;

@Service
public class ClientGoodsServiceImpl implements ClientGoodsService {

    @Autowired(required = false)
    EGoodsMapper eGoodsMapper;
    
    @Autowired(required = false)
    EGoodsTypeMapper eGoodsTypeMapper;
    
    @Autowired(required = false)
    ETimeLimitedMapper eTimeLimitedTypeMapper;
    

	@Override
	public EGoods selectByPrimaryKey(int goodsId) {
		return eGoodsMapper.selectByPrimaryKey(goodsId);
	}

	@Override
	public EGoodsType selectGoodsTypeByPrimaryKey(String typeCode) {
		return eGoodsTypeMapper.selectByPrimaryKey(typeCode);
	}

	@Override
	public EGoods selectValuedByPrimaryKey(int id) {
		
		return eGoodsMapper.selectValuedByPrimaryKey(id);
	}

	@Override
	public List<ETimeLimited> selectTimeLimitedGoods() {
		return eTimeLimitedTypeMapper.select6OrderByDate();
	}

	@Override
	public List<EGoodsType> selectGoodsTypeByCodeEqualFour() {
		return eGoodsTypeMapper.selectByCodeEqualFour();
	}

	@Override
	public List<EGoodsType> selectGoodsTypeByByPreCode(String code) {
		return eGoodsTypeMapper.selectByPreCode(code);
	}

	@Override
	public List<EGoods> searchGoodsByKeyword(String keyword,String typeCode, Double minPrice, Double maxPrice) {
		return eGoodsMapper.searchGoodsByKeyword(keyword,typeCode,minPrice, maxPrice);
	}

	@Override
	public int updateStorageById(EGoods goods) {
		return eGoodsMapper.updateByPrimaryKeySelective(goods);	
	}


	
    

   
    
}
