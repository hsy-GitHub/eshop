package org.zhku.eshop.controller.admin;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.service.admin.GoodsTypeService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/goodsType")
@Api("GoodsTypeController")
public class GoodsTypeController {

    @Autowired
    private GoodsTypeService service;

    @GetMapping("/majors")
    @ApiOperation("获取大类别")
    public List<EGoodsType> majors(){
        return service.getMajorCategory();
    }

    @GetMapping("/details")
    @ApiOperation("获取小类别")
    public List<EGoodsType> details(String preCode){
        return service.getDetailCategory(preCode);
    }

    @GetMapping("/goodsTypeManage")
    public String goodsTypeManage(String precode,Model model){
        List<EGoodsType> majorCategory = service.getMajorCategory();
        model.addAttribute("majorCategory",majorCategory);
        model.addAttribute("detailCategory",service.getDetailCategory(precode!=null?precode:majorCategory.get(0).getCode()));
        return "admin/goodsTypeManage";
    }

    @PostMapping("/addDetail")
    @ApiOperation("添加新的小类别")
    public boolean addDetail(@RequestBody EGoodsType eGoodsType){
        return service.addDetail(eGoodsType);
    }

    @PostMapping("/addMajor")
    @ApiOperation("添加新的大类别")
    public boolean addMajor(@RequestBody EGoodsType eGoodsType){
        return service.addMajor(eGoodsType);
    }

    @PostMapping("/delete")
    public List<String> delete(@RequestBody Map<String,List<String>> map){
        List<String> codes = map.get("codes");
       return service.deleteList(codes);
    }

    @PostMapping("/updateDetail")
    public boolean updateDetail(@RequestBody EGoodsType goodsType){
        return service.updateDetail(goodsType);
    }

    @GetMapping("/detail/{code}")
    public EGoodsType getDetailByCode(@PathVariable("code")String code){
        return service.getDetailByCode(code);
    }
}
