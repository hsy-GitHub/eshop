package org.zhku.eshop.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EPictureCarousel;

@Mapper
@Repository
public interface EPictureCarouselMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EPictureCarousel record);

    int insertSelective(EPictureCarousel record);

    EPictureCarousel selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EPictureCarousel record);

    int updateByPrimaryKey(EPictureCarousel record);

	List<EPictureCarousel> selectAll();
}