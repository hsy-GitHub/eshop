package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EUserMapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class AdminService {
    @Autowired
    private EUserMapper userMapper;

    public EUser login(String username,String password){
        EUser admin = userMapper.selectByUserIdAndPasswordAndRole(username, password, 2);
        return admin;
    }

    public ResponseResult<EUser> getUserByLikedUsernameAndRole(String userId, String role, int pageNum, int pageSize) {
        role = role!=null&&role.equals("0")?null:role;
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        List<EUser> list = userMapper.selectLikeUserIdByRoleLimit(userId, role, start, pageSize);
        int total = userMapper.countLikeUserIdByRole(userId, role);
        ResponseResult<EUser> result = new ResponseResult<EUser>(list,total);
        return result;
    }

    public int countLikeUserIdByRole(String userId,String role) {
        return userMapper.countLikeUserIdByRole(userId,role);
    }

    public void deleteUsers(List<Integer> ids) {
        ids.forEach(id->userMapper.deleteByPrimaryKey(id));
    }


    public void antiaAtivate(int id) {
        EUser finded = userMapper.selectByPrimaryKey(id);
        if(finded!=null)
            finded.setActiveStatus(0);
        userMapper.updateByPrimaryKey(finded);
    }

    public void ativate(int id) {
        EUser finded = userMapper.selectByPrimaryKey(id);
        if(finded!=null)
            finded.setActiveStatus(1);
        userMapper.updateByPrimaryKey(finded);
    }

    public EUser getUserById(int id) {
        return userMapper.selectByPrimaryKey(id);
    }

    public boolean update(EUser newly) {
        EUser olded = userMapper.selectByPrimaryKey(newly.getId());
        olded.setPassWord(newly.getPassWord());
        olded.setName(newly.getName());
        olded.setSex(newly.getSex());
        olded.setEmail(newly.getEmail());
        olded.setPhone(newly.getPhone());
        olded.setAddress(newly.getAddress());
        olded.setBirthday(newly.getBirthday());
        olded.setProvince(newly.getProvince());
        olded.setCity(newly.getCity());
        int flag = userMapper.updateByPrimaryKey(olded);
        return flag>=1?true:false;
    }

    public boolean add(EUser newly) throws ParseException {
        if (newly.getId()!=null){
            return false;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
        newly.setCreateDate(date);
        newly.setActiveStatus(1);
        int insert = userMapper.insert(newly);
        return insert==1?true:false;
    }

    public EUser getUserByUsername(String username) {
        return userMapper.selectByUsername(username);
    }

}
