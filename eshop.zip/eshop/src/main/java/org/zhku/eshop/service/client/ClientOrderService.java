package org.zhku.eshop.service.client;


import java.util.List;

import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderItem;
import org.zhku.eshop.entity.EUser;

public interface ClientOrderService {

	public List<EOrder> selectOrderByUserId(String loginId);

	public List<EOrderItem> selectGoodsIdByOrderId(int orderId);

	public int updateTradingStatus(Integer orderId);

	public int insertOrderBackId(EOrder order);

	public int insertOrderItem(EOrderItem orderItem);

	public int updateOrderById(EOrder order);

	public int deleteByPrimaryKey(int parseInt);

	public int deleteItemByOrderId(int parseInt);

    

}
