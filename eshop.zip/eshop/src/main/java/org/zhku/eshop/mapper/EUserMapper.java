package org.zhku.eshop.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EUser;

import java.util.List;

@Mapper
@Repository
public interface EUserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EUser record);

    int insertSelective(EUser record);

    EUser selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EUser record);

    int updateByPrimaryKey(EUser record);

	EUser selectByEmailAndPwd(String loginId, String password);

	EUser selectByUserIdAndPwd(String loginId, String password);

	EUser selectByPhoneAndPwd(String loginId, String password);

    EUser selectByUserIdAndPasswordAndRole(@Param("userId") String userId, @Param("password") String password,@Param("role")int role);

    List<EUser> selectLikeUserIdByRoleLimit(@Param("userId")String userId,@Param("role")String role,@Param("start")int start,@Param("num") int num);

    int countLikeUserIdByRole(@Param("userId")String userId,@Param("role")String role);

    EUser selectByUsername(@Param("username")String username);
}