package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EOrderItemDetail;
import org.zhku.eshop.mapper.EOrderItemMapper;

import java.util.List;

@Service
public class EOrderItemService {
    @Autowired
    EOrderItemMapper mapper;

    public List<EOrderItemDetail>getOrderDetailByOrderId(int id){
        return mapper.selectOrderDetailByOrderId(id);
    }


    private void appendPicPath(List<EOrderItemDetail> list){
        list.forEach(item->item.setImage("/client/images/product/"+item.getImage()));
    }
}
