package org.zhku.eshop.controller.admin;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.service.admin.AdminService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

@Api("AdminController")
@RestController
@RequestMapping("/admin/user")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @ApiOperation("登录")
    @ApiImplicitParams({
            @ApiImplicitParam(name="username",value="用户名",required = true,dataType = "String"),
            @ApiImplicitParam(name="password",value = "密码",required = true,dataType = "String")})
    @PostMapping("/login")
    public boolean login(String username, String password, boolean saveCookie,
                         HttpSession session, HttpServletResponse response){
        EUser login = adminService.login(username, password);
        if(login!=null) {
            session.setAttribute("user",login);
            if(saveCookie){
                Cookie cookie1 = new Cookie("username",username);
                Cookie cookie2 = new Cookie("password",password);
                cookie1.setMaxAge(60*60*12);
                cookie1.setPath("/admin/login.html");
                cookie2.setMaxAge(60*60*12);
                cookie2.setPath("/admin/login.html");
                response.addCookie(cookie1);
                response.addCookie(cookie2);
            }else {
                Cookie cookie1 = new Cookie("username",null);
                Cookie cookie2 = new Cookie("password",null);
                cookie1.setMaxAge(60*60*12);
                cookie1.setPath("/admin/login.html");
                cookie2.setMaxAge(60*60*12);
                cookie2.setPath("/admin/login.html");
                response.addCookie(cookie1);
                response.addCookie(cookie2);
            }
            return true;
        }
        else {
            return false;
        }
    }

    @GetMapping("/list")
    @ApiOperation("用户列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name="username",value="登录名",dataType = "String"),
            @ApiImplicitParam(name="role",value = "角色ID",dataType = "String"),
            @ApiImplicitParam(name="pageNum",value = "页码",dataType = "String")})
    public ResponseResult<EUser> getUsers(String username, String role,int pageNum,int pageSize){
        return adminService.getUserByLikedUsernameAndRole(username,role,pageNum,pageSize);
    }

    @GetMapping("/getUserByID")
    public EUser getUserByID(int id){
        return adminService.getUserById(id);
    }

    @GetMapping("/getUserByUsername")
    public EUser getUserByID(String username){
        return adminService.getUserByUsername(username);
    }

    @PostMapping("/add")
    public boolean add(@RequestBody EUser newly) throws ParseException {
        return adminService.add(newly);
    }

    @PostMapping("/update")
    public boolean update(@RequestBody EUser newly){
        return adminService.update(newly);
    }

    @PostMapping("/delete")
    public boolean delete(@RequestBody Map<String,List<Integer>> map){
        adminService.deleteUsers(map.get("ids"));
        return true;
    }

    @GetMapping("/antiActivate")
    public boolean antiActivate(int id){
        adminService.antiaAtivate(id);
        return true;
    }

    @GetMapping("/activate")
    public boolean activate(int id){
        adminService.ativate(id);
        return true;
    }

    @GetMapping("/logout")
    public void logout(HttpSession session){
        session.setAttribute("user",null);
    }

    @GetMapping("/test")
    public void test(String username){
        System.out.println();
    }

}
