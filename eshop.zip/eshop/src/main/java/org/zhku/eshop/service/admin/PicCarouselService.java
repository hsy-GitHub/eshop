package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.EPictureCarouselMapper;

import java.util.List;

@Service
public class PicCarouselService {
    @Autowired
    private EPictureCarouselMapper mapper;

	public List<EPictureCarousel> getAllList() {
		return mapper.selectAll();
	}

	public boolean delete(Integer id) {
		int count = mapper.deleteByPrimaryKey(id);
		return count>0?true:false;
	}

	public boolean add(EPictureCarousel pictureCarousel) {
		int count = mapper.insertSelective(pictureCarousel);
		return count>0?true:false;
	}

	public EPictureCarousel getById(int id) {
		return  mapper.selectByPrimaryKey(id);
	}

	public boolean update(EPictureCarousel picCarousel) {
		int count = mapper.updateByPrimaryKeySelective(picCarousel);
		return count>0?true:false;
	}

   
}
