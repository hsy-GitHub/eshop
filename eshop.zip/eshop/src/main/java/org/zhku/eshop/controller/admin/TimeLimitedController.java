package org.zhku.eshop.controller.admin;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.common.io.Files;

import io.swagger.annotations.Api;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.util.StringUtils;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.service.admin.GoodsService;
import org.zhku.eshop.service.admin.PicCarouselService;
import org.zhku.eshop.service.admin.TimeLimitedService;
import org.zhku.eshop.util.AdminUtil;

import java.io.*;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@Api("GoodController")
@RestController
@RequestMapping("/admin/timeLimited")
public class TimeLimitedController {
    @Autowired
    TimeLimitedService timeLimitedService;
    
    @Autowired
    GoodsService goodsService;
    
    @GetMapping("/list")
    public List<ETimeLimited> getAllList(){	
    	List<ETimeLimited> timeLimitedList =timeLimitedService.getAllList(); 
        return timeLimitedList;
    }
    
    @GetMapping("/getGoodsList")
    public List<EGoods> getGoodsList(){
        return goodsService.getGoodsList();
    }
    //停用限选
    @GetMapping("/antiActivate")
    public boolean antiActivate(int id){
        return timeLimitedService.changeIsEnd(id,1);
    }
    
    @GetMapping("/activate")
    public boolean activate(int id){
        return timeLimitedService.changeIsEnd(id,0);
    }
    
    @PostMapping("/delete")
    public boolean delete(@RequestParam("id") Integer  id){
        boolean success = timeLimitedService.delete(id);
        return success;
    }
    
    @PostMapping("/add")
    public boolean add(String limitDate,String goodsId){
        //避免参数恶意传输
    	 if (limitDate==null||"".equals(limitDate)||goodsId==null||"".equals(goodsId)){    
             return false;
         }
    	 ETimeLimited timeLimited = new ETimeLimited();
    	timeLimited.setIsEnd(0);
    	 Date a= new Date();
    	 try {
    		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //24小时制
    		 a= sdf.parse(limitDate);
    	 } catch (ParseException e) {
    		 return false;
    		 
    	 } 
    	 Timestamp t = new Timestamp(a.getTime());
    	 timeLimited.setLimitDate(t);
    	 timeLimited.setGoodsId(Integer.parseInt( goodsId));
    	 boolean success = timeLimitedService.add(timeLimited);
    	 return success;
    }
    
    @GetMapping("/getTimeLimited/{id}")
    @ResponseBody
    public ETimeLimited getByID(@PathVariable("id")int id){
    	ETimeLimited timeLimited =timeLimitedService.getById(id);
        return timeLimited;
    }
    
    @PostMapping("/edit")
    public boolean edit(String id,String limitDate,String goodsId){
    	//如果limitDate为空就不修改该字段
    	 if (id==null||"".equals(id)||goodsId==null||"".equals(goodsId)){     		 
             return false;
         }
    	 ETimeLimited timeLimited1 =  timeLimitedService.getById(Integer.parseInt(id));
    	 ETimeLimited timeLimited = new ETimeLimited();
    	 timeLimited.setId(Integer.parseInt(id));
    	 timeLimited.setLimitDate(timeLimited1.getLimitDate());//先设置为原来的，
    	 //因为如果设为null，会因为实体中属性的@JsonFormat，而自动填现在的日期
    	 timeLimited.setIsEnd(0);
    	 
    	 if(limitDate!=null&&!"".equals(limitDate)) {
    		 Date a= new Date();
	    	 try {
	    		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  //24小时制
	    		 a= sdf.parse(limitDate);
	    		 Timestamp t = new Timestamp(a.getTime()); 	 
	        	 timeLimited.setLimitDate(t);
	    	 } catch (ParseException e) {
	    		 return false; 
	    	 }
    	 }
    	 
    	 timeLimited.setGoodsId(Integer.parseInt( goodsId));
    	 boolean success =	timeLimitedService.update(timeLimited);     
    	 return success;
    }
    
 
}
