package org.zhku.eshop.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.ETimeLimited;

@Mapper
@Repository
public interface ETimeLimitedMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ETimeLimited record);

    int insertSelective(ETimeLimited record);

    ETimeLimited selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ETimeLimited record);

    int updateByPrimaryKey(ETimeLimited record);

	List<ETimeLimited> select6OrderByDate();

	List<ETimeLimited> selectAllList();

	int changeIsEnd(int id, int i);
}