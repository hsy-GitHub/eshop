package org.zhku.eshop.controller.client;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.EShopCartVO;
import org.zhku.eshop.service.client.ClientGoodsService;



@Controller
public class ClientEShopCartController {
	@Autowired
	private ClientGoodsService goodsService;
	
	/***
	 * 显示购物车页面
	 * @param id 商品的id
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/eshop/showShopCart")
	public String showGoodsDetails(Model m,HttpServletRequest request) throws UnsupportedEncodingException {
		String loginId = "";
		//先在session域找用户id
		if(request.getSession().getAttribute("loginId")!=null) {	
			loginId = String.valueOf(request.getSession().getAttribute("loginId"));
			if(request.getSession().getAttribute("loginName")!=null) {	
				String loginName = String.valueOf(request.getSession().getAttribute("loginName"));
				m.addAttribute("loginName",loginName);
			}
		}
		
		
		if("".equals(loginId) || loginId==null) {
			return "client/login";	
		}else {
			Cookie[] cookies = request.getCookies();
	        Cookie userCartCookie = null;
	        String userCartCookieName = loginId+"Cart";//登录的用户的购物车的名字为用户id+'Cart'
	        for (Cookie cookie : cookies) {
	            if (userCartCookieName.equals(cookie.getName())) { //获取购物车cookie
	            	userCartCookie = cookie;
	            }
	        }
	      //判断购物车是否为空
	        String cartValue="";
	        //如果已经存在对应的购物车
	        if (userCartCookie != null) {
	            // 获取cookie中String类型的value
	            cartValue = URLDecoder.decode(userCartCookie.getValue(), "utf-8");//从cookie获取购物车
	            // 判断value是否为空或者""字符串，cookie里存id|num,id|num
	            if (cartValue != null && !"".equals(cartValue)) {
	            	//把数据取出来
	            	String[] idNumArr=cartValue.split("#");
	            	List<EShopCartVO>  eShopCartList= new ArrayList();
	            	for(String idNum:idNumArr) {

	            		String[] idAndNum= idNum.split("\\|");
	            		//如果以竖线为分隔符，则split的时候需要加上两个斜杠【\\】进行转义
	            		String goodsId = idAndNum[0];
	            		String num = idAndNum[1];	            		
	            		
	            		if(goodsId!=null&&!"".equals(goodsId)) {
	            			
		            		//根据取出来的商品id，对数据库进行查找
		            		EGoods goods= goodsService.selectByPrimaryKey(Integer.parseInt(goodsId));
		            		EShopCartVO eShopCartVO = new EShopCartVO();
		            		eShopCartVO.setId(goods.getId());
		            		eShopCartVO.setImage(goods.getImage());
		            		eShopCartVO.setTitle(goods.getTitle());
		            		eShopCartVO.setFavorablePrice(goods.getFavorablePrice());
		            		eShopCartVO.setStorage(goods.getStorage());//库存
		            		eShopCartVO.setNum(Integer.parseInt(num));//加入购物车的数量
		            		eShopCartList.add(eShopCartVO);
	            		}
	            	}
	            	m.addAttribute("shopCartList",eShopCartList );
	            	m.addAttribute("isHasShopCart",true);//为true告诉页面有数据
	            }else {
	            	//购物车的cookie有，但是没有数据
	            	m.addAttribute("isHasShopCart",false);
	            }
	        }else {
	        	//  如果不存在对应的购物车，那就显示没有数据，再看看链接，转到首页
	        	m.addAttribute("isHasShopCart",false);
	        }
	        
		}
		
		//menu的数据加载
		Map mapList= new ClientIndexController().initiMenu(goodsService);
		m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
		m.addAttribute("goodsTypeList",mapList.get("map"));
		
		return "client/buycar";
	}
	

	/**
	 * 从商品细节的页面点击加入购物车按钮后的触发的控制器，
	 * @param request
	 * @param response
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping("/eshop/addShopCart")
	@ResponseBody  
	public int showGoodsByTypeCode(HttpServletRequest request,HttpServletResponse response) 
			throws UnsupportedEncodingException {
		//getParameter才行，  getAttribute不行
		String goodsId = (String) request.getParameter("goodsId");		
		String num = (String) request.getParameter("num");

		String loginId="";
		//先在session域找用户id
		if(request.getSession().getAttribute("loginId")!=null) {	
			loginId = String.valueOf(request.getSession().getAttribute("loginId"));
		}
		
		if("".equals(loginId)||loginId==null) {
			return 0;	//用作ajax的返回信息
		}else {
			Cookie[] cookies = request.getCookies();
	        Cookie userCartCookie = null;
	        String userCartCookieName = loginId+"Cart";//登录的用户的购物车的名字为用户id+'Cart'
	        for (Cookie cookie : cookies) {
	            if (userCartCookieName.equals(cookie.getName())) { //获取购物车cookie
	            	userCartCookie = cookie;
	            }
	        }
	        
	        //判断购物车是否为空
	        String cartValue="", newCartValue="";
	        //如果已经存在对应的购物车
	        if (userCartCookie != null&&!"".equals(userCartCookie)) {
	            // 获取cookie中String类型的value
	            cartValue = URLDecoder.decode(userCartCookie.getValue(), "utf-8");//从cookie获取购物车
	            // 判断value是否为空或者""字符串，cookie里存id|num#id|num
	            if (cartValue != null && !"".equals(cartValue)) {
	            	//如果购物车中已有数据,把数据取出来
	            	String[] idNumArr=cartValue.split("#");
	            	boolean flag = false;
	            	//先查找该商品是否已经加入购物车了，如果有就把原本加入购物车的数量变成现在加入购物车的数量
	            	for(String idNum:idNumArr) {             		
	            		String[] idAndNum= idNum.split("\\|");
	            		//如果以竖线为分隔符，则split的时候需要加上两个斜杠【\\】进行转义
	            		String goodsId2 = idAndNum[0];
	            		if(goodsId2.equals(goodsId)) {
	            			idAndNum[1] = num;
	            			flag = true;
	            		}
	            
	            		String idNum1 = idAndNum[0]+'|'+idAndNum[1];
	            		newCartValue = newCartValue+idNum1+"#";    		
	            	}
	            	//如果没有该商品没有加入过购物车就重新加入
	            	if(!flag) {
	            		newCartValue = newCartValue+goodsId+'|'+num+"#";    
	            	}            	
	            }else {
	            	newCartValue = goodsId+'|'+num+'#';   
	            }
	        }else {
	        	//  如果不存在对应的购物车，那就制作购物车cookie数据
	        	newCartValue = goodsId+'|'+num+'#';
	        	userCartCookie = new Cookie(userCartCookieName, URLEncoder.encode(newCartValue, "utf-8"));
	        }
	        userCartCookie.setValue(newCartValue);
	        userCartCookie.setPath("/eshop");//设置在/eshop路径下都可以访问该cookie
	        userCartCookie.setMaxAge(60 * 60);//设置cookie有效时间为60分钟
	        response.addCookie(userCartCookie);//添加cookie
	        return 1;
		} //用户已登录的分支结束
	}
	
}
