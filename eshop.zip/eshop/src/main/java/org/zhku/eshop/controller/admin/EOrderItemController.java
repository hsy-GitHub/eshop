package org.zhku.eshop.controller.admin;

import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zhku.eshop.entity.EOrderItemDetail;
import org.zhku.eshop.service.admin.EOrderItemService;

import java.util.List;

@Api("EOrderItemController")
@RestController
@RequestMapping("/admin/orderItems")
public class EOrderItemController {
    @Autowired
    private EOrderItemService service;

    @GetMapping("/list/{orderId}")
    public List<EOrderItemDetail>getItemsByOrderId(@PathVariable("orderId")int orderId){
        List<EOrderItemDetail> orderDetailByOrderId = service.getOrderDetailByOrderId(orderId);
        return orderDetailByOrderId;
    }
}
