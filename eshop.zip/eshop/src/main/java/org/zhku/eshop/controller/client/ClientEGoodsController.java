package org.zhku.eshop.controller.client;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.service.client.ClientGoodsService;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;



@Controller
public class ClientEGoodsController {
	@Autowired
	private ClientGoodsService goodsService;
	
	/***
	 * 显示选中的商品细节
	 * @param id 商品的id
	 * @return
	 */
	@RequestMapping("/eshop/details/{id}")
	public String showGoodsDetails(@PathVariable(value="id") int id,Model m,HttpServletRequest request) {
		
		if(request.getSession().getAttribute("loginName")!=null) {	
			String loginName = (String) request.getSession().getAttribute("loginName");
			m.addAttribute("loginName",loginName);
		}
		EGoods goods =  goodsService.selectValuedByPrimaryKey(id);
		if(goods!=null) {
			//m不仅要传goods的信息，还要配置导航栏，导航栏上还有两个参数的传递
			String typeCode= goods.getTypeCode();
			if(!"".equals(typeCode)&&typeCode!=null) {
				if(typeCode.length()==4) {
					EGoodsType goodsType_1= goodsService.selectGoodsTypeByPrimaryKey(typeCode);
					String sortName_1 = goodsType_1.getName();
					m.addAttribute("sortName_1", sortName_1);
					m.addAttribute("sort_1", typeCode);
					
				}else if(typeCode.length()>4){
					String sort_1 = typeCode.substring(0, 4);
					EGoodsType goodsType_1= goodsService.selectGoodsTypeByPrimaryKey(sort_1);
					EGoodsType goodsType_2= goodsService.selectGoodsTypeByPrimaryKey(typeCode);
					//保证name一定是可用的
					String sortName_1 = goodsType_1.getName();
					String sortName_2 = goodsType_2.getName();
					m.addAttribute("sort_1", sort_1);
					m.addAttribute("sort_2", typeCode);
					m.addAttribute("sortName_1", sortName_1);
					m.addAttribute("sortName_2", sortName_2);
				}
			}
			m.addAttribute("goods", goods);
			//menu的数据加载
			Map mapList= new ClientIndexController().initiMenu(goodsService);
			m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
			m.addAttribute("goodsTypeList",mapList.get("map"));
			return "client/details";
		}
		return "redirect:/eshop/home";
	}
	
	
	/**
	 * 按照在搜索框中输入的关键词来搜索商品
	 * @param keyword //required=true，则参数必须要传
	 * @param typeCode       商品类型
	 * @param minPrice        限定搜索的最低金额
	 * @param maxPrice       限定搜索的最高金额
	 * @param pageNum      第几页
	 * @param pageSize       一页显示多少数据
	 * @param m
	 * @return
	 */
	@RequestMapping("/eshop/searchGoodsByKeyword")
	public String searchGoodsByKeyword(@RequestParam(value="keyword" ,required =false) String keyword,
			@RequestParam(value="typeCode" ,required =false) String typeCode,
			@RequestParam(value="minPrice" ,required =false) String minPrice,
			@RequestParam(value="maxPrice" ,required =false) String maxPrice,
			@RequestParam(value="pageNum" ,required =false, defaultValue = "1") int pageNum,
			@RequestParam(value="pageSize" ,required =false, defaultValue = "15") int pageSize,	Model m,HttpServletRequest request) {
		
		//最上面的一栏显示登录人的信息
		if(request.getSession().getAttribute("loginName")!=null) {	
			String loginName = (String) request.getSession().getAttribute("loginName");
			m.addAttribute("loginName",loginName);
		}
		
		//设置菜单下的分类导航,sort_1为四位的编码，sortName_1为对应的编码的备注
		String sort_1=null, sortName_1=null,sort_2=null, sortName_2=null;
		
		//menu的数据加载
		Map mapList= new ClientIndexController().initiMenu(goodsService);
		m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
		m.addAttribute("goodsTypeList",mapList.get("map"));
		
		//xml要设置如果这个为空，就是查找全部的商品，
		List<EGoods> goodsList = null;
//		keyword=keyword.trim();//如果没有传keyword，即为空，这个就会报错
		if(keyword==null || "".equals(keyword) || "null".equals(keyword)) { //第三个条件是分页传进来的keyword=null的情况
			keyword=null;
		}
		
		//对商品的分类显示的操作
		boolean flag = false;
		if(typeCode==null || "".equals(typeCode) || "null".equals(typeCode)) {
			flag = true;
			typeCode=null;
		}else {
			typeCode=typeCode.trim();
			flag = false;
			//如果有传商品的code就设置对应的显示
			if(typeCode.length()==4) {
				EGoodsType goodsType_1= goodsService.selectGoodsTypeByPrimaryKey(typeCode);
				sort_1=typeCode;
				sortName_1 = goodsType_1.getName();
				m.addAttribute("sortName_1", sortName_1);
				m.addAttribute("sort_1", typeCode);
				
			}else if(typeCode.length()>4){
				sort_1 = typeCode.substring(0, 4);
				EGoodsType goodsType_1= goodsService.selectGoodsTypeByPrimaryKey(sort_1);
				EGoodsType goodsType_2= goodsService.selectGoodsTypeByPrimaryKey(typeCode);
				//也可以得到Name,但是要处理，所以保证name一定是可用的
				sortName_1 = goodsType_1.getName();
				sortName_2 = goodsType_2.getName();
				m.addAttribute("sort_1", sort_1);
				m.addAttribute("sort_2", typeCode);
				m.addAttribute("sortName_1", sortName_1);
				m.addAttribute("sortName_2", sortName_2);
			}
		}
		
		
		
		//对价格参数的处理
		if(minPrice==null || "".equals(minPrice) || "null".equals(minPrice)) {
			//如果没有限制最低金额，最低金额默认为null
			minPrice=null;
		}
		if(maxPrice==null || "".equals(maxPrice) || "null".equals(maxPrice)) {
			maxPrice=null;
		}
		//对minPrice和maxPrice处理
		Double minPrice_Double =0.0;
		Double maxPrice_Double =0.0;
		if(minPrice!=null) {
			minPrice_Double = Double.parseDouble(minPrice);
		}
		if(maxPrice!=null) {
			maxPrice_Double = Double.parseDouble(maxPrice);
		}
		
		PageHelper.startPage(pageNum,pageSize);//这个要在mapper接口被检测前使用//紧跟着的第一个select方法会被分页
		goodsList= goodsService.searchGoodsByKeyword(keyword,typeCode,minPrice_Double ,maxPrice_Double);
		PageInfo<EGoods> page = new PageInfo<EGoods>(goodsList);
		m.addAttribute("pageInfo", page);//封装成PageInfo类来传递
		
		//如果没有typeCode的参数，就取查到的上面查到的第一个商品的类型作为分类
		if(flag) {
			if(goodsList.size()!=0) {
				String code1 = goodsList.get(0).getTypeCode();
				sort_1 = code1.substring(0, 4);
				EGoodsType goodsType_1= goodsService.selectGoodsTypeByPrimaryKey(sort_1);
				//也可以得到Name,但是要处理，所以保证name一定是可用的
				sortName_1 = goodsType_1.getName();
				m.addAttribute("sort_1", sort_1);
				m.addAttribute("sortName_1", sortName_1);
			}
		}
		//根据sort_1来取得品牌的图片路径和code
		List<EGoodsType> sortGoodsTypeList = goodsService.selectGoodsTypeByByPreCode(sort_1);
		List<String> pinPaiPicUrl = new ArrayList();
		//赋予品牌对应的商标的地址
		for(EGoodsType goodsType : sortGoodsTypeList ) {
			String picUrl = goodsType.getCode();
			picUrl = "/client/images/pinpai/"+sort_1+"/"+picUrl+".jpg";
			pinPaiPicUrl.add(picUrl);
		}
		m.addAttribute("sortGoodsTypeList", sortGoodsTypeList);
		m.addAttribute("sortGoodsTypeListNum", sortGoodsTypeList.size());//该分类有多少个品牌
		m.addAttribute("pinPaiPicUrl", pinPaiPicUrl);
		
		m.addAttribute("keyword", keyword);
		m.addAttribute("typeCode", typeCode);
		m.addAttribute("minPrice", minPrice);
		m.addAttribute("maxPrice", maxPrice);

		return "client/goodsList";
	}
	
}
