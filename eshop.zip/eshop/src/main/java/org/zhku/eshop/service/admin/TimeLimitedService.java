package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.ETimeLimitedMapper;

import java.util.List;

@Service
public class TimeLimitedService {
    @Autowired
    private ETimeLimitedMapper mapper;
    @Autowired
    private EGoodsMapper goodsMapper;
    
    public boolean add(ETimeLimited goods){
        goods.setId(null);
       int flag =  mapper.insert(goods);
        return  flag==1?true:false;
    }

    public boolean update(ETimeLimited goods){
        int flag = mapper.updateByPrimaryKeySelective(goods);
        return flag==1?true:false;
    }

    public boolean delete(int id){
        int flag = mapper.deleteByPrimaryKey(id);
        return flag==1?true:false;
    }

    public ETimeLimited getById(int id) {
        return mapper.selectByPrimaryKey(id);
    }

	public List<ETimeLimited> getAllList() {
		return mapper.selectAllList();
	}
	//修改抢购表中为id=id的数据的isEnd为i
	public boolean changeIsEnd(int id, int i) {
		  int flag = mapper.changeIsEnd(id, i);
	      return flag==1?true:false;
	}



}
