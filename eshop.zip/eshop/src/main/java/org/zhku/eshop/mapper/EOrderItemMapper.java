package org.zhku.eshop.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EOrderItem;
import org.zhku.eshop.entity.EOrderItemDetail;
import org.zhku.eshop.entity.EOrderItemKey;

@Mapper
@Repository
public interface EOrderItemMapper {
    int deleteByPrimaryKey(EOrderItemKey key);

    int insert(EOrderItem record);

    int insertSelective(EOrderItem record);

    EOrderItem selectByPrimaryKey(EOrderItemKey key);

    int updateByPrimaryKeySelective(EOrderItem record);

    int updateByPrimaryKey(EOrderItem record);

	List<EOrderItem> selectGoodsIdByOrderId(int orderId);

    List<EOrderItemDetail> selectOrderDetailByOrderId(@Param("order_id") int order_id);

	int deleteItemByOrderId(@Param("orderId")int orderId);
}