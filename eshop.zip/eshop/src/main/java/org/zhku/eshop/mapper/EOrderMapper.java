package org.zhku.eshop.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderDetail;

@Mapper
@Repository
public interface EOrderMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EOrder record);

    int insertSelective(EOrder record);

    EOrder selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EOrder record);

    int updateByPrimaryKey(EOrder record);

	List<EOrder> selectOrderByUserId(String loginId);

	int updateTradingStatus(Integer orderId);

    List<EOrder> selectByUserIdPageable(@Param("userId") int userId, @Param("start") int start,@Param("pageSize") int pageSize);

    List<EOrder> selectByTradingStatusEqualNullAndAlipayEqualOne(@Param("start") int start,@Param("size") int size);

    @Select("select count(*) from e_order where `TRADING_STATUS` is null and `ALIPAY`=1")
    int countByTradingStatusEqualNullAndAlipayEqualOne();

	int insertOrderBackId(EOrder order);

    @Select("select count(*) from e_order where `TRADING_STATUS`=0")
    int countByTradingStatusEqualZero();

    List<EOrder> selectByTradingStatusEqualZero(@Param("start") int start,@Param("size") int size);

    @Select("select count(*) from e_order where `TRADING_STATUS`=1")
    int countByTradingStatusEqualOne();

    List<EOrder> selectByTradingStatusEqualOne(@Param("start") int start,@Param("size") int size);


    List<EOrderDetail>selectByTradingStatus(@Param("tradingStatus")String tradingStatus ,@Param("start") int start,@Param("size") int size,@Param("username")String username);

    int countByTradingStatus(@Param("tradingStatus")String tradingStatus,@Param("username")String username);
}