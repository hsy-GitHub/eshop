package org.zhku.eshop.controller.admin;

import com.google.common.io.Files;


import io.swagger.annotations.Api;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.util.StringUtils;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.service.admin.GoodsService;
import org.zhku.eshop.service.admin.PicCarouselService;
import org.zhku.eshop.util.AdminUtil;
import org.zhku.eshop.util.FileUtil;

import java.io.*;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@Api("GoodController")
@RestController
@RequestMapping("/admin/pictureCarousel")
public class PictureCarouselController {
    @Autowired
    PicCarouselService picCarouselService;
    
    @Autowired
    GoodsService goodsService;
    
    @GetMapping("/list")
    public List<EPictureCarousel> getAllList(){
    	//对返回的list的图片请求做处理，只取后面的数字
    	List<EPictureCarousel> pictureCarouselList =picCarouselService.getAllList();
    	if(pictureCarouselList!=null) {
    		for(EPictureCarousel pictureCarousel : pictureCarouselList) {
    			String requestUrl = pictureCarousel.getRequestUrl();
    			//requestUrl数据库的存法是   /eshop/details/5
    			String[] index = requestUrl.split("/");
    			String goodsId = index[index.length-1];
    			pictureCarousel.setRequestUrl(goodsId);
    		}
    	}
        return pictureCarouselList;
    }
    
    @GetMapping("/getGoodsList")
    public List<EGoods> getGoodsList(){
        return goodsService.getGoodsList();
    }

    
    
    @PostMapping("/delete")
    public boolean delete(@RequestParam("id") Integer  id){
    	
    	 //旧的图片就删除
    	EPictureCarousel olded = picCarouselService.getById(id);
    	String oldimageUrl = olded.getImageUrl();
    	String[] index = oldimageUrl.split("/");
		String newimageUrl = index[index.length-1];
		
        File oldFile = new File("src/main/resources/static/client/images/ad",newimageUrl);
        oldFile.delete();//删除文件
    	
        boolean success = picCarouselService.delete(id);
        return success;
    }
    
    @PostMapping("/add")
    public boolean add(MultipartFile uploadImage,String id,HttpServletRequest request){
        //避免参数恶意传输
    	 if (uploadImage==null||"".equals(uploadImage.getOriginalFilename())||id==null||"".equals(id)){    
             return false;
         }
    	 //对图片处理	 
    	 EPictureCarousel pictureCarousel = new EPictureCarousel();
    	 String saveName = AdminUtil.getPicNameByTime(Files.getFileExtension(uploadImage.getOriginalFilename()));
    	 pictureCarousel.setImageUrl("/client/images/ad/"+saveName);
         try {
         	if (StringUtils.isNotBlank(uploadImage.getOriginalFilename())) { // 如果文件名不空就是成功上传
 				FileUtils.copyInputStreamToFile(uploadImage.getInputStream(), new File("src/main/resources/static/client/images/ad/",saveName));	
 				
 				//上传到服务器
 		        //设置文件上传路径
 		        String filePath = request.getSession().getServletContext().getRealPath("client/images/ad/");   
				FileUtil.uploadFile(uploadImage.getBytes(), filePath, saveName);
				
         	}
         	
         } catch (Exception e) { 
             return false;
         }
        pictureCarousel.setRequestUrl("/eshop/details/"+id);
    	boolean success = picCarouselService.add(pictureCarousel);
    	return success;
	
    }
    
    @GetMapping("/getPictureCarousel/{id}")
    @ResponseBody
    public EPictureCarousel getByID(@PathVariable("id")int id){
    	EPictureCarousel pictureCarousel =picCarouselService.getById(id);
    	if(pictureCarousel!=null) {
    		String requestUrl = pictureCarousel.getRequestUrl();
			//requestUrl数据库的存法是   /eshop/details/5
			String[] index = requestUrl.split("/");
			String goodsId = index[index.length-1];
			pictureCarousel.setRequestUrl(goodsId);
    	}	
        return pictureCarousel;
    }
    
    @PostMapping("/edit")
    public boolean edit(MultipartFile uploadImage,EPictureCarousel picCarousel,HttpServletRequest request){
    	
    	  if (picCarousel==null||picCarousel.getRequestUrl()==null||"".equals(picCarousel.getRequestUrl())||picCarousel.getId()==null){        	
              return false;
          }
    	
    	  //想得到传过来的轮播图对应的商品编号，再接上前台实现的请求id,传过来的imageUrl就是文件
    	  String requestUrl_GoodsId = picCarousel.getRequestUrl();
    	  String requestUrl = "/eshop/details/"+requestUrl_GoodsId;
    	  picCarousel.setRequestUrl(requestUrl);
    	  picCarousel.setImageUrl(null);
          if(uploadImage==null||uploadImage.getOriginalFilename().equals("")){
                //不更新图片
        	  picCarouselService.update(picCarousel);
                return true;
            }else {
            	 //旧的图片就删除
            	EPictureCarousel olded = picCarouselService.getById(picCarousel.getId());
            	String oldimageUrl = olded.getImageUrl();
            	String[] index = oldimageUrl.split("/");
    			String newimageUrl = index[index.length-1];
    			
                File oldFile = new File("src/main/resources/static/client/images/ad",newimageUrl);
                oldFile.delete();//删除文件
                try {
                	 String saveName = AdminUtil.getPicNameByTime(Files.getFileExtension(uploadImage.getOriginalFilename()));
                	 picCarousel.setImageUrl("/client/images/ad/"+saveName);
                	if (StringUtils.isNotBlank(uploadImage.getOriginalFilename())) { // 如果文件名不空就是成功上传
        				FileUtils.copyInputStreamToFile(uploadImage.getInputStream(), new File("src/main/resources/static/client/images/ad/",saveName));	
        				
        				//上传到服务器
         		        //设置文件上传路径
         		        String filePath = request.getSession().getServletContext().getRealPath("client/images/ad/");   
        				FileUtil.uploadFile(uploadImage.getBytes(), filePath, saveName);
                	}
                	picCarouselService.update(picCarousel);
                } catch (Exception e) {        	
                    return false;
                }
            }
        return true;
    }
}
