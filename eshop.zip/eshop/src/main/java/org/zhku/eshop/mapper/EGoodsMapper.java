package org.zhku.eshop.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import java.util.List;

@Mapper
@Repository
public interface EGoodsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EGoods record);

    int insertSelective(EGoods record);

    EGoods selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(EGoods record);

    int updateByPrimaryKeyWithBLOBs(EGoods record);

    int updateByPrimaryKey(EGoods record);
    /**
     * 根据EGoods的主键来得到上架日期为今天包括今天之后的，既可以上架的商品
     * @param id
     * @return
     */
	EGoods selectValuedByPrimaryKey(int id);

	List<EGoods> searchGoodsByKeyword(@Param("keyword")String keyword,
																@Param("typeCode")String typeCode, 
																@Param("minPrice")Double minPrice, 
																@Param("maxPrice")Double maxPrice);

    List<EGoods> selectByTitleAndBrandAndTypeCodePageable(@Param("title") String title,
                                                          @Param("brandName") String brandName,
                                                          @Param("typeCode") String typeCode,
                                                          @Param("start") int start,
                                                          @Param("pageSize") int pageSize);
    int selectCountByTitleAndBrandAndTypeCodePageable(@Param("title") String title,
            @Param("brandName") String brandName,
            @Param("typeCode") String typeCode);

    @Select("select count(*) from e_goods where `TYPE_CODE` =#{typeCode}")
    int countByTypeCode(String typeCode);

	List<EGoods> selectAllGoods();
}