package org.zhku.eshop.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EOrderVO {
	private Integer id;
	private String orderCode;
	private Date createDate;
	private Integer tradingStatus;
	private Integer alipay;
	
	public Integer getAlipay() {
		return alipay;
	}
	public void setAlipay(Integer alipay) {
		this.alipay = alipay;
	}
	public List <EOrderGoods> eOrderGoods=new ArrayList();
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public List<EOrderGoods> geteOrderGoods() {
		return eOrderGoods;
	}
	public void seteOrderGoods(List<EOrderGoods> eOrderGoods) {
		this.eOrderGoods = eOrderGoods;
	}
	public List<EOrderGoods> getOrderGoodsList() {
		return eOrderGoods;
	}
	public void setOrderGoodsList(List<EOrderGoods> orderGoodsList) {
		this.eOrderGoods = orderGoodsList;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Integer getTradingStatus() {
		return tradingStatus;
	}
	public void setTradingStatus(Integer tradingStatus) {
		this.tradingStatus = tradingStatus;
	}
	public class EOrderGoods{
		private String title;
		private String image;
		private Double price;
		private Double totalAmount;
		private Integer orderNum;
		
		
		public Double getTotalAmount() {
			return totalAmount;
		}
		public void setTotalAmount(Double totalAmount) {
			this.totalAmount = totalAmount;
		}
		public Integer getOrderNum() {
			return orderNum;
		}
		public void setOrderNum(Integer orderNum) {
			this.orderNum = orderNum;
		}

		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
	}
}
