package org.zhku.eshop.entity;

import java.util.Date;

public class EShopCartVO {
    private Integer id;

    private String title;

    private Double favorablePrice;

    private Integer storage;

    private String image;
    
    private int num;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Double getFavorablePrice() {
		return favorablePrice;
	}

	public void setFavorablePrice(Double favorablePrice) {
		this.favorablePrice = favorablePrice;
	}

	public Integer getStorage() {
		return storage;
	}

	public void setStorage(Integer storage) {
		this.storage = storage;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

   
}