package org.zhku.eshop.service.client;


import java.util.List;

import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.entity.EUser;

public interface ClientGoodsService {

	public EGoods selectByPrimaryKey(int goodsId);

	public EGoodsType selectGoodsTypeByPrimaryKey(String typeCode);
	 /**
     * 根据EGoods的主键来得到上架日期为今天包括今天之后的，既可以上架的商品
     * @param typeCode
     * @return
     */
	public EGoods selectValuedByPrimaryKey(int id);

	public List<ETimeLimited> selectTimeLimitedGoods();

	public List<EGoodsType> selectGoodsTypeByCodeEqualFour();

	public List<EGoodsType> selectGoodsTypeByByPreCode(String code);

	public List<EGoods> searchGoodsByKeyword(String keyword, String typeCode, Double minPrice, Double maxPrice);

	public int updateStorageById(EGoods goods);
}
