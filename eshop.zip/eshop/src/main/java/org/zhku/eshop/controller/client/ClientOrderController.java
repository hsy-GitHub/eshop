package org.zhku.eshop.controller.client;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderItem;
import org.zhku.eshop.entity.EOrderVO;
import org.zhku.eshop.entity.EOrderVO.EOrderGoods;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.service.client.ClientGoodsService;
import org.zhku.eshop.service.client.ClientOrderService;
import org.zhku.eshop.service.client.ClientUserService;


@Controller
public class ClientOrderController {
	@Autowired
	private ClientUserService userService;
	@Autowired
	private ClientOrderService orderService;
	@Autowired
	private ClientGoodsService goodsService;
	
	@RequestMapping("/eshop/toMyOrder")
	public String showLogin(HttpServletRequest request,Model m) {
		String loginId = "";
		String password = "";
		
		//先在session域找用户id
		if(request.getSession().getAttribute("loginId")!=null) {	
			loginId = String.valueOf(request.getSession().getAttribute("loginId"));
			if(request.getSession().getAttribute("loginName")!=null) {	
				String loginName = String.valueOf(request.getSession().getAttribute("loginName"));
				m.addAttribute("loginName",loginName);
			}
		}
		
	    if(!"".equals(loginId)&&loginId!=null) {
	    	//进入该用户的订单
	    	//渲染html
	    	List<EOrderVO> allOrderList = initMyOrder(loginId);
	    	request.setAttribute("orderList", allOrderList);
	    	//menu的数据加载
			Map mapList= new ClientIndexController().initiMenu(goodsService);
			m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
			m.addAttribute("goodsTypeList",mapList.get("map"));
	    	return "client/myOrder";	
	    }
		
	    //判断是否在cookie中有记住用户登录的痕迹
		//获取当前站点的所有Cookie
		Cookie[] cookies = request.getCookies();
		if(cookies!=null) {
		    for (int i = 0; i < cookies.length; i++) {//对cookies中的数据进行遍历，找到用户名、密码的数据
		    	if ("loginId".equals(cookies[i].getName())) {
		    		loginId = cookies[i].getValue();
		    	} else if ("passWord".equals(cookies[i].getName())) {
		    		password = cookies[i].getValue();
		    	}
			}
		}
	
	    if(!"".equals(loginId)&&loginId!=null&&!"".equals(password)&&password!=null) {
	    	EUser user  = userService.selectByPrimaryKey(Integer.parseInt(loginId));
	    	if(user!=null) {
	    		//保存在session上
	    		request.getSession().setAttribute("loginId", user.getId());
	    		//如果有这个用户则重定向到首页
	    		//menu的数据加载
	    		Map mapList= new ClientIndexController().initiMenu(goodsService);
	    		m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
	    		m.addAttribute("goodsTypeList",mapList.get("map"));
	    		return "client/myOrder";
	    	}
	    	else{
	    		return "client/login";	
	    	}
	    }else {
	    	return "client/login";	    	
	    }
	}
	/**
	 * 渲染“我的订单页面”的方法
	 * @param loginId 用户的id
	 * @return
	 */
	private List<EOrderVO> initMyOrder(String loginId) {
		//每一个订单是一个数组，数组里有很多EOrderVO，然后我的订单是由很多订单组成
		int id = Integer.parseInt(loginId);//用户id
		List<EOrderVO> allOrderList = new ArrayList();
		List<EOrder>  orderList =orderService.selectOrderByUserId(loginId); //存订单
		
		if(orderList!=null) {
			for(EOrder or: orderList) {
				int orderId= or.getId();	
				//每一个订单
				EOrderVO order = new EOrderVO();
				order.setId(orderId);
				order.setCreateDate(or.getCreateDate());
				order.setOrderCode(or.getOrderCode());
				order.setTradingStatus(or.getTradingStatus());
				order.setAlipay(or.getAlipay());
				
				List<EOrderItem>  orderItemList = orderService.selectGoodsIdByOrderId(orderId);//得到物品的id
				List <EOrderVO.EOrderGoods>  eOrderGoodsList =new ArrayList();
				if(orderItemList!=null) {
					for(EOrderItem oritem: orderItemList) {
						int goodsId= oritem.getGoodsId();
					    EGoods  eGoods= goodsService.selectByPrimaryKey(goodsId);
					    EOrderGoods eOrderGoods=  order.new EOrderGoods();
					    
					    //初始化订单的物品信息
					    eOrderGoods.setImage(eGoods.getImage());
					    eOrderGoods.setOrderNum(oritem.getOrderNum());
					    eOrderGoods.setPrice(eGoods.getPrice());
					    eOrderGoods.setTitle(eGoods.getTitle());
					    
					    eOrderGoods.setTotalAmount(eOrderGoods.getPrice()*eOrderGoods.getOrderNum());
				    
					    eOrderGoodsList.add(eOrderGoods);
					}
				}
				order.setOrderGoodsList(eOrderGoodsList);
				allOrderList.add(order);
			}
		}	
		return allOrderList;
	}
	/**
	 * 订单页面中按下“确认收货”链接的控制器
	 * @param orderId 订单的id
	 * @return
	 */
	@RequestMapping("/eshop/confirm/{orderId}")  //这里使用？id=的方式传不进这个控制器
	public String orderConfirm(@PathVariable(value = "orderId") String orderId) {
		int count = orderService.updateTradingStatus(Integer.parseInt(orderId));
		return "redirect:/eshop/toMyOrder";
		
	}
	
	/**
	 * 取消订单的控制器
	 * @param orderId
	 * @return
	 */
	@RequestMapping("/eshop/cancelOrder/{orderId}")
	public String cancelOrder(@PathVariable(value = "orderId") String orderId) {
		//因为要注意外键约束，先删EGoodsItem表的
		orderService.deleteItemByOrderId(Integer.parseInt(orderId));
		orderService.deleteByPrimaryKey(Integer.parseInt(orderId));
		return "redirect:/eshop/toMyOrder";
	}
	
	/**
	 * 购物车页面的提交订单按钮
	 * @param m
	 * @param request
	 * @return
	 */
	@RequestMapping("/eshop/orderSubmit")
	@Transactional
	public String orderSubmit(@RequestParam(value="goodsInfo", required=false) String goodsInfo,
			@RequestParam(value="total_price", required=false)String total_price,Model m,HttpServletRequest request) {
		
		//先检验数据的正确性，不知道上面的required有没有起作用
		if(goodsInfo!=null&&!"".equals(goodsInfo)&&total_price!=null&&!"".equals(total_price)) {
			String[] id_numList = goodsInfo.split(",");
			for(String id_nums : id_numList) {
				String[] id_num = id_nums.split("\\*");
				String id = id_num[0];
				String num = id_num[1];
				if(id==null||"".equals(id)||num==null||"".equals(num)) {
					return "client/login";
				}
			}
		}else {
			return "client/login";
		}
		
		
		boolean isInsertOrder = false;
		//既要查找该商品信息也要把商品插入到订单表中
		if(goodsInfo!=null&&!"".equals(goodsInfo)&&total_price!=null&&!"".equals(total_price)) {
			//1.商品插入到订单表中
			String loginId = "";
			int orderId = 0;
			//先在session域找用户id
			if(request.getSession().getAttribute("loginId")!=null) {	
				loginId = String.valueOf(request.getSession().getAttribute("loginId"));
				if(request.getSession().getAttribute("loginName")!=null) {	
					String loginName = String.valueOf(request.getSession().getAttribute("loginName"));
					m.addAttribute("loginName",loginName);
				}
				//getOrderIdByTime方法创建一个订单号
				String orderCode = getOrderIdByTime(loginId);
				EOrder order = new EOrder();
				order.setUserId(Integer.parseInt(loginId));
				order.setOrderCode(orderCode);
				order.setAlipay(0);
				order.setTotalAmount(Double.parseDouble(total_price));
				
				//Timestamp填入数据库时自然会符合规范的
				Timestamp t = new Timestamp(System.currentTimeMillis());
				order.setCreateDate(t);
				int count = orderService.insertOrderBackId(order);
				orderId = order.getId();				
				
				if(count>0) {
					 isInsertOrder = true;
				}else {
					return "client/login";
				}
			}else {
				return "client/login";
			}
			
			//只有上面插入成功了才能把信息插入订单明细表
			if( isInsertOrder&&orderId!=0) {
				List<EGoods> goodsList = new ArrayList();
				List<Integer> buyGoodsNumList = new ArrayList();
				String goodsIdListString = "";
				String buyGoodsNumListString = "";
				
				String[] id_numList = goodsInfo.split(",");
				for(String id_nums : id_numList) {
					String[] id_num = id_nums.split("\\*");
					String id = id_num[0];
					String num = id_num[1];
					if(id!=null&&!"".equals(id)&&num!=null&&!"".equals(num)) {
						//2. 把信息插入订单明细表
						EOrderItem  orderItem= new EOrderItem();
						orderItem.setGoodsId(Integer.parseInt(id));
						orderItem.setOrderNum(Integer.parseInt(num));
						orderItem.setOrderId(orderId);
						int count = orderService.insertOrderItem(orderItem);

						if(count>0) {
							//3. 查找该商品信息
							EGoods goods = goodsService.selectByPrimaryKey(Integer.parseInt(id));	
							goodsList.add(goods);
							buyGoodsNumList.add(Integer.parseInt(num));
							
							goodsIdListString=goodsIdListString+id+'*';
							buyGoodsNumListString = buyGoodsNumListString+num+'*';
							
						}else {
							return "client/login";
						}
					}
				}
				m.addAttribute("goodsList", goodsList);
				m.addAttribute("buyGoodsNumList", buyGoodsNumList);
				m.addAttribute("total_price", total_price);
				m.addAttribute("orderId", orderId);
				m.addAttribute("goodsIdListString", goodsIdListString);
				m.addAttribute("buyGoodsNumListString", buyGoodsNumListString);
				
			}
		}else {
			return "redirect:/eshop/showShopCart";
		}
		
		return "client/orderSubmit";	
	}
	
	/**
	 * 生成订单号，形式是用户id+下单的时间
	 * @param loginId
	 * @return
	 */
	public static String getOrderIdByTime(String loginId) {
			SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
			String newDate=sdf.format(new Date());	
			return "PO_"+loginId+"_"+newDate;
	}
		
	
	/**
	 * 返回0代表支付不成功，1代表支付成功，
	 * @param m
	 * @param request
	 * @return
	 */
	@RequestMapping("/eshop/pay")
	@Transactional
	@ResponseBody
	public int orderPay(Model m,HttpServletRequest request) {
		String orderId=  request.getParameter("orderId"); 
		String goodsIdListString =request.getParameter("goodsIdListString");
		String buyGoodsNumListString = request.getParameter("buyGoodsNumListString");

		boolean isValued = true;
		//首先查看这些数据是否有效
		String[] goodsIdList = goodsIdListString.split("\\*");
		String[] buyGoodsNumList = buyGoodsNumListString.split("\\*");
		for(int i=0;i<goodsIdList.length; i++) {		
			//如果库存不够
			EGoods goods1= goodsService.selectByPrimaryKey(Integer.parseInt(goodsIdList[i]));
			if(goods1==null) {
				isValued = false;
				break;
			}
			if(goods1.getStorage()<Integer.parseInt(buyGoodsNumList[i])) {
				isValued = false;
				break;
			}else {
				//查看商品id是否正确
				EGoods goods= goodsService.selectByPrimaryKey(Integer.parseInt(goodsIdList[i]));
				if(goods==null) {
					isValued = false;
					break;
				}
			}
		}
		
		//如果数据有效，就进入支付
		if(isValued) {
			for(int i=0;i<goodsIdList.length; i++) {
				//先看看库存够不够，不够就返回1，				
				//如果库存够
				EGoods goods1= goodsService.selectByPrimaryKey(Integer.parseInt(goodsIdList[i]));
				if(goods1==null) {
					isValued = false;
					break;
				}
				if(goods1.getStorage()>=Integer.parseInt(buyGoodsNumList[i])) {
					int newStorage=0;
					newStorage = goods1.getStorage()-Integer.parseInt(buyGoodsNumList[i]);
					EGoods goods= new EGoods();
					goods.setId(goods1.getId());
					goods.setStorage(newStorage);
					goodsService.updateStorageById(goods);	
				}else {
					return 1;
				}
			}
			//修改订单状态
			EOrder order= new EOrder();
			order.setId(Integer.parseInt(orderId));
			order.setAlipay(1);
//			order.setTradingStatus(0);
			int count = orderService.updateOrderById(order);
			if(count>0) {
				return 1;	
			}else {
				return 0;
			}
		}else { //数据无效，重新提交订单
			return 0;
		}

	}
}
