package org.zhku.eshop.controller.admin;

import com.google.common.io.Files;

import io.swagger.annotations.Api;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.util.StringUtils;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.service.admin.GoodsService;
import org.zhku.eshop.util.AdminUtil;
import org.zhku.eshop.util.FileUtil;

import java.io.*;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


@Api("GoodController")
@RestController
@RequestMapping("/admin/good")
public class GoodController {
    @Autowired
    GoodsService goodsService;

    @GetMapping("/list")
    public ResponseResult<EGoods> getListByConditionPageble(EGoods goods,int pageNum,int pageSize){
        return goodsService.getGoodsByTitleAndBrandNameAndTypeCodePageable(goods.getTitle(),goods.getBrandName(),goods.getTypeCode(),pageNum,pageSize);
    }

    @PostMapping("/add")
    public boolean add(MultipartFile uploadImage,EGoods goods,HttpServletRequest request){
        //避免参数恶意传输
        if (uploadImage==null||goods.getTitle()==null||
                goods.getBrandName()==null||goods.getPrice()==null||
                goods.getStorage()==null||goods.getTypeCode()==null){        	
            return false;
        }
        goods.setCreateDate(new Date());
        goods.setGroundingDate(goods.getCreateDate());

        int position = goodsService.getPosition(goods.getTypeCode());
        String saveName = AdminUtil.getPirtureName(goods.getTypeCode(),goods.getCreateDate(),position,Files.getFileExtension(uploadImage.getOriginalFilename()));
        goods.setImage(saveName);
        try {
        	if (StringUtils.isNotBlank(uploadImage.getOriginalFilename())) { // 如果文件名不空就是成功上传
				FileUtils.copyInputStreamToFile(uploadImage.getInputStream(), new File("src/main/resources/static/client/images/product/",saveName));	
				
				//上传到服务器
 		        //设置文件上传路径
 		        String filePath = request.getSession().getServletContext().getRealPath("client/images/product/");   
				FileUtil.uploadFile(uploadImage.getBytes(), filePath, saveName);       	
        	}
            goodsService.add(goods);
        } catch (Exception e) {        	
            return false;
        }
        return true;
    }

    @PostMapping("/delete")
    public boolean delete(@RequestParam("ids[]") List<Integer> ids){
    	//删除原来的图片
    	for(int id:ids) {
    		EGoods olded = goodsService.getById(id);
    		String imageUrl = olded.getImage();
    		File oldFile = new File("src/main/resources/static/client/images/product",imageUrl);
    	    oldFile.delete();//删除文件
    	}
        boolean success = goodsService.deleteGoods(ids);
        return success;
    }

    @GetMapping("/good/{id}")
    @ResponseBody
    public EGoods getByID(@PathVariable("id")int id){
        return goodsService.getById(id);
    }
    
    @PostMapping("/edit")
    public boolean edit(MultipartFile uploadImage,EGoods modified,HttpServletRequest request){
    	//如果没有上传图片就用原来的图片，如果上传了图片，就删除原来的图片，图片的名字就用回原本的图片的名字
        EGoods olded = goodsService.getById(modified.getId());

        modified.setCreateDate(olded.getCreateDate());
        modified.setGroundingDate(olded.getGroundingDate());
        modified.setImage(olded.getImage());//图片的名字就用回原本的图片的名字
        String saveName = olded.getImage();
        if(uploadImage==null||uploadImage.getOriginalFilename().equals("")){
            //不更新图片
        	goodsService.update(modified);
            return true;
        }else {
        	 //旧的图片就删除
            File oldFile = AdminUtil.saveFile(olded.getImage());
            oldFile.delete();//删除文件
        	try {
        		if (StringUtils.isNotBlank(uploadImage.getOriginalFilename())) { // 如果文件名不空就是成功上传	
					FileUtils.copyInputStreamToFile(uploadImage.getInputStream(), new File("src/main/resources/static/client/images/product/",saveName));	
					
					//上传到服务器
	 		        //设置文件上传路径
	 		        String filePath = request.getSession().getServletContext().getRealPath("client/images/product/");   
					FileUtil.uploadFile(uploadImage.getBytes(), filePath, saveName);  
        		}
        		goodsService.update(modified);
        	}catch (Exception e) {
            	return false;
			}	
        }
        return true;
    }
    
    
}
