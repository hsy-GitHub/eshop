package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.EGoodsTypeMapper;

import java.util.ArrayList;
import java.util.List;

@Service
public class GoodsTypeService {
    @Autowired
    private EGoodsTypeMapper goodsTypeMapper;

    @Autowired
    private EGoodsMapper goodsMapper;

    public List<EGoodsType> getMajorCategory() {
        return goodsTypeMapper.selectByCodeEqualFour();
    }

    public List<EGoodsType> getDetailCategory(String precode) {
        return goodsTypeMapper.selectByPreCode(precode);
    }

    public boolean addDetail(EGoodsType eGoodsType) {
        if (eGoodsType.getCode().length()!=4){
            return false;
        }
        String preCode = eGoodsType.getCode();
        //取出最大Code数用于构建新的Code
        String maxCode =goodsTypeMapper.selectMaxByPreCode(preCode);
        int newNum = Integer.parseInt(maxCode.substring(4))+1;

        //补充前导0
        eGoodsType.setCode(eGoodsType.getCode()+String.format("%04d", newNum));
        int insert = goodsTypeMapper.insert(eGoodsType);
        return insert==1;
    }

    public List<String> deleteList(List<String> codes) {
        List<String>errorCodes = new ArrayList<>();
        codes.forEach(code->{
            if (deleteOne(code)){
                goodsTypeMapper.deleteByPrimaryKey(code);
            }else {
                errorCodes.add(code);
            }
        });
        return errorCodes;
    }

    private boolean deleteOne(String goodType){
        int count = goodsMapper.countByTypeCode(goodType);
        return count>0?false:true;
    }

    public boolean addMajor(EGoodsType eGoodsType) {
        if (eGoodsType.getCode()!=null||eGoodsType.getName()==null){
            return false;
        }
        String maxPreCode = goodsTypeMapper.selectMaxPreCode();
        int newPreCode = Integer.parseInt(maxPreCode)+1;
        eGoodsType.setCode(String.format("%04d",newPreCode));
        int insert = goodsTypeMapper.insert(eGoodsType);
        return insert==1;
    }

    public boolean updateDetail(EGoodsType goodsType) {
        if(goodsType.getCode()==null||goodsTypeMapper.selectByPrimaryKey(goodsType.getCode())==null){
            return false;
        }
        int i = goodsTypeMapper.updateByPrimaryKey(goodsType);
        return i==1;
    }

    public EGoodsType getDetailByCode(String code) {
        return goodsTypeMapper.selectByPrimaryKey(code);
    }
}
