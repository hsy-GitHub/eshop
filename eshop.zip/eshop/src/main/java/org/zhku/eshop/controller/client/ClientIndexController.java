package org.zhku.eshop.controller.client;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.entity.EShopCartVO;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.entity.ETimeLimitedGoodsVO;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.service.client.ClientGoodsService;
import org.zhku.eshop.service.client.ClientIndexService;
import org.zhku.eshop.service.client.ClientUserService;
import org.zhku.eshop.util.CookieUtil;


@Controller
public class ClientIndexController {
	
	@Autowired
	private ClientUserService userService;
	
	@Autowired
	private ClientGoodsService goodsService;
	
	@Autowired
	private ClientIndexService indexService;
	
	@RequestMapping("/eshop/home")
	public String showLogin(Model m,HttpServletRequest request) {
		//还要渲染主页面
		//查找在cookie上有没有记录用户的登录信息
		String[] loginIdAndPsw = new CookieUtil().getLoginIdAndPsw(request);
		String loginId = loginIdAndPsw[0];
		String password = loginIdAndPsw[1];
	    if(!"".equals(loginId)&&loginId!=null&&!"".equals(password)&&password!=null) {
	    	EUser user  = userService.selectByPrimaryKey(Integer.parseInt(loginId));
	    	if(user!=null) {
	    		m.addAttribute("loginName",user.getName());
	    		//保存在session上
	    		request.getSession().setAttribute("loginId", user.getId());
	    		request.getSession().setAttribute("loginName", user.getName());
	    	}
	    }else {
	    	if(request.getSession().getAttribute("loginId")!=null) {
				int loginId_int = (int) request.getSession().getAttribute("loginId");//因为int不能为null，默认为0
				EUser user  = userService.selectByPrimaryKey(loginId_int);
				if(user!=null) {
					m.addAttribute("loginName",user.getName());
					request.getSession().setAttribute("loginName", user.getName());
				}
			}
	    }
	    
		
		//购物车的商品数量也要查，还没登录就写0个商品，session取用户id
		int shopCartNum =0;
		try {
			shopCartNum = new CookieUtil().getShopCartNum(request);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		m.addAttribute("shopCartNum",shopCartNum);

		//menu菜单的渲染
		//先把货品类型中的四位数编号的类型先筛选出来，然后取前面7个编号作为首页显示的，其他作为“更多”显示
		Map mapList= initiMenu(goodsService);
		m.addAttribute("moreGoodsTypeList", mapList.get("MoreMap"));
		m.addAttribute("goodsTypeList",mapList.get("map"));
		
			
		//轮播图
		List<EPictureCarousel> pictureCarouselLsit=indexService.selectPictureCarousel();
			
		//限选商品的信息是，先从限选表中找到6个最接近今天时间的商品list,有限选时间，id，
		List<ETimeLimited> timeLimitedList= goodsService.selectTimeLimitedGoods();
		
		//然后以id来找到对应的商品VOlist，页面有个隐藏的限选的时间，js实现倒数
		List<ETimeLimitedGoodsVO> eTimeLimitedGoodsVOList = new ArrayList();
		for(ETimeLimited eTimeLimited : timeLimitedList) {
			EGoods eGoods= goodsService.selectByPrimaryKey(eTimeLimited.getGoodsId());
			//查到的商品的库存大于0才显示
			if(eGoods.getStorage()>0) {
				ETimeLimitedGoodsVO eTimeLimitedGoodsVO = new ETimeLimitedGoodsVO();
				eTimeLimitedGoodsVO.setId(eGoods.getId());
				eTimeLimitedGoodsVO.setLimitDate(eTimeLimited.getLimitDate());
				eTimeLimitedGoodsVO.setFavorablePrice(eGoods.getFavorablePrice());
				eTimeLimitedGoodsVO.setImage(eGoods.getImage());
				eTimeLimitedGoodsVO.setBrandName(eGoods.getBrandName());
				eTimeLimitedGoodsVO.setTypeCode(eGoods.getTypeCode());
				eTimeLimitedGoodsVOList.add(eTimeLimitedGoodsVO);
			}
		}
		
		m.addAttribute("eTimeLimitedGoodsList",eTimeLimitedGoodsVOList);
		m.addAttribute("pictureCarouselLsit",pictureCarouselLsit);
		m.addAttribute("pictureCarouselNum",pictureCarouselLsit.size()-1);
		return "client/index";
	}
	
	
	/**
	 * 初始化首页的导航栏menu，因为在其他类中调用了该方法，而goodsService又是自创建的，所以只能当参数传了
	 * @param goodsService
	 * @return
	 */
	public Map initiMenu(ClientGoodsService goodsService){
		//menu菜单需要查，四位数的就是li,大于四位数的就是ul，
		//先把货品类型中的四位数编号的类型先筛选出来，然后取前面7个编号作为首页显示的，其他作为“更多”显示
		List<EGoodsType> goodsType = goodsService.selectGoodsTypeByCodeEqualFour();
		//先不考虑有没有七种goodsType
		Map map=new LinkedHashMap();	//有顺序地插入取出
		for(int i=0;i<=6;i++) {
			String code = goodsType.get(i).getCode();
			List<EGoodsType> goodsType2 = goodsService.selectGoodsTypeByByPreCode(code);
			map.put(goodsType.get(i), goodsType2);
//					System.out.println(code);
		}
		//“更多”的数据
		Map MoreMap=new HashMap();
		for(int i=goodsType.size()-1;i>=7;i--) {
			String code = goodsType.get(i).getCode();
			List<EGoodsType> goodsType2 = goodsService.selectGoodsTypeByByPreCode(code);
			MoreMap.put(goodsType.get(i), goodsType2);
		}
		
		Map mapList=new LinkedHashMap();
		mapList.put("map", map);
		mapList.put("MoreMap", MoreMap);
		return mapList;
	}
	
	//注销链接
	@RequestMapping("/eshop/toLogout")
	public String toLogout(HttpServletRequest request,HttpServletResponse response) {
		 new CookieUtil().Logout(request, response);
		return "client/login";
	}
}
