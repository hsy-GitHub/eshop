package org.zhku.eshop.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import org.zhku.eshop.entity.EGoodsType;

import java.util.List;

@Mapper
@Repository
public interface EGoodsTypeMapper {
    int deleteByPrimaryKey(String code);

    int insert(EGoodsType record);

    int insertSelective(EGoodsType record);

    EGoodsType selectByPrimaryKey(String code);

    int updateByPrimaryKeySelective(EGoodsType record);

    int updateByPrimaryKey(EGoodsType record);

    List<EGoodsType>selectByCodeEqualFour();

    List<EGoodsType>selectByPreCode(@Param("code")String code);

    @Select("select code from e_goods_type where `CODE` like concat(#{preCode},'%') order by `CODE` desc limit 0,1")
    String selectMaxByPreCode(@Param("preCode") String preCode);

    @Select("select code from e_goods_type where length(`CODE`)=4  order by `CODE` desc limit 0,1")
    String selectMaxPreCode();

}