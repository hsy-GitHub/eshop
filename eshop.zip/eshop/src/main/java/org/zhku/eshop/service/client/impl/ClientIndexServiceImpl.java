package org.zhku.eshop.service.client.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.mapper.EGoodsMapper;
import org.zhku.eshop.mapper.EGoodsTypeMapper;
import org.zhku.eshop.mapper.EPictureCarouselMapper;
import org.zhku.eshop.mapper.ETimeLimitedMapper;
import org.zhku.eshop.service.client.ClientIndexService;
import java.util.List;

@Service
public class ClientIndexServiceImpl implements ClientIndexService {

    @Autowired(required = false)
    EGoodsMapper eGoodsMapper;
    
    @Autowired(required = false)
    EGoodsTypeMapper eGoodsTypeMapper;
    
    @Autowired(required = false)
    EPictureCarouselMapper eTimeLimitedTypeMapper;

	@Override
	public List<EPictureCarousel> selectPictureCarousel() {
		return eTimeLimitedTypeMapper.selectAll();
	}
    
    
}
