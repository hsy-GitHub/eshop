package org.zhku.eshop.controller.admin;

import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EOrderDetail;
import org.zhku.eshop.service.admin.OrderService;

@Api("OrderController")
@RestController
@RequestMapping("/admin/order")
public class OrderController {
    @Autowired
    private OrderService service;

    @GetMapping("/list/{type}/{pageNum}/{pageSize}")
    public ResponseResult<EOrderDetail> getOrderByType(@PathVariable("type")int type,
                                                       @PathVariable("pageNum")int pageNum,
                                                       @PathVariable("pageSize") int pageSize,
                                                       String username){
        switch (type){
            case 1:
                return service.getOrderNeededSent(pageNum,pageSize,username);
            case 2:
                return service.getOrderInTransporting(pageNum,pageSize,username);
            case 3:
                return service.getOrderCompleted(pageNum,pageSize,username);
        }
        return null;
    }

    @GetMapping("/sent/{id}")
    public boolean sent(@PathVariable("id")int id){
        boolean sent = service.sent(id);
        return sent;
    }
}
