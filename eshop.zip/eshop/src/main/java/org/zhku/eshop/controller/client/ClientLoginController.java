package org.zhku.eshop.controller.client;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.service.client.ClientUserService;
import org.zhku.eshop.util.CookieUtil;


@Controller
public class ClientLoginController {
	final String[] allCode = {"d8w8" , "avnx" , "6x9s" , "9ur2"};
	@Autowired
	private ClientUserService userService;
	
	@RequestMapping("/eshop/login")
	public String showLogin(HttpServletRequest request) {
		//判断是否在cookie中有记住用户登录的痕迹
		String[] loginIdAndPsw = new CookieUtil().getLoginIdAndPsw(request);
		String loginId = loginIdAndPsw[0];
		String password = loginIdAndPsw[1];
	    if(!"".equals(loginId)&&loginId!=null&&!"".equals(password)&&password!=null) {
	    	EUser user  = userService.selectByPrimaryKey(Integer.parseInt(loginId));
	    	if(user!=null) {
	    		//保存在session上
	    		request.getSession().setAttribute("loginId", user.getId());
	    		//如果有这个用户则重定向到首页
	    		return "redirect:/eshop/home";
	    	}
	    	else{
	    		return "client/login";	
	    	}
	    }else {
	    	return "client/login";	    	
	    }
	}
	
	//从登录界面进入
	@RequestMapping("/eshop/toHome")
	public String showHome(HttpServletRequest request,HttpServletResponse response) {
		String  loginId=  request.getParameter("loginId");
		String  password= request.getParameter("password");
		String remPwd = request.getParameter("rememberPwd");//这里显示的复选框的值只有on选/null不选
		String  codeId = request.getParameter("codeId");//当前的验证码图片的ID
		String  code = request.getParameter("code");//用户输入的待验证的验证码
		EUser user = null;
		
		//验证验证码是否正确
		if(!"".equals(codeId)&&codeId!=null&&!"".equals(code)&&code!=null) {
			 if(!allCode[Integer.parseInt(codeId)-1].equals(code.toLowerCase())) {
				 request.setAttribute("msg", "验证码输入错误");
				 //验证码输入错误
				 return "client/login";
			 }
		}else {
			 return "client/login";
		}
	
	   //验证用户账号密码
		if(!"".equals(loginId)&&loginId!=null&&!"".equals(password)&&password!=null) {
			//loginId有两个可能：用户账号/已验证手机
			
			//已验证手机
			user = userService.checkUserbyPhone(loginId,password);
			if(user==null) {
				//用户名即是用户id
				user = userService.checkUserbyUserID(loginId,password);
					if(user==null) {
						request.setAttribute("msg", "用户名或密码输入错误");
						return "client/login";
					}
			}
		}else {
			request.setAttribute("msg", "用户名或密码输入错误");
			return "client/login";
		}
		
		
		//如果有该用户，判断是否记住密码
		if(!"".equals(remPwd)&&remPwd!=null) {
			//记住密码的操作，把loginId和passWord存到cookie里
			Cookie idCookie = new Cookie("loginId", user.getId().toString());
			 //设置Cookie的有效期为3天
			idCookie.setMaxAge(60 * 60 * 24 * 3);
			Cookie pwdCookie = new Cookie("passWord", user.getPassWord());
			pwdCookie.setMaxAge(60 * 60 * 24 * 3);
			response.addCookie(idCookie);
			response.addCookie(pwdCookie);	
		}
		
		//1是会员，2是管理员
		if(user.getRole()==1) {
			//在session域记录登录用户的id
			request.getSession().setAttribute("loginId", user.getId());
			//其实这个是要转向渲染index.html的
			return "redirect:/eshop/home";
		}else {
			request.getSession().setAttribute("loginId", user.getId());
			request.getSession().setAttribute("user",user);
			return "redirect:/admin/index.html";
		}
		
	}
	
	@RequestMapping("/eshop/register")
	public String register(EUser user,HttpServletRequest request) {
		//先对一些特别的类型数据进行转换，如生日（date），性别（int）,
		//所以故意不设置html里的user的这个字段的列名
		String birthday_string = request.getParameter("birthday_string");
		String sex_string = request.getParameter("sex_string");
		java.sql.Date birthday=java.sql.Date.valueOf(birthday_string);
		user.setBirthday(birthday);
		user.setSex(Integer.parseInt(sex_string));
		user.setActiveStatus(1); //没有激活功能就手动激活
		user.setRole(1);
		//设置时间格式为yyyy-mm-dd
		 java.util.Date utilDate=new Date();       
	    java.sql.Date sqlDate=new java.sql.Date(utilDate.getTime());  
		user.setCreateDate(sqlDate);
		int count =0;
		try {
			count = userService.addUser(user);
		}catch (Exception e) {
			request.setAttribute("msg", "注册不成功");
		}
		if(count>0) {
			//注册后再登录一次
			return "client/login";
		}else {
			request.setAttribute("msg", "注册不成功");
			return "client/register";
		}
	}
	
	@RequestMapping("/eshop/toRegister")
	public String ToRegister() {
		return "client/register";
	}
	
}
