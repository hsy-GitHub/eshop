package org.zhku.eshop.util;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AdminUtil {
    //根据商品号如00010002以及新插入的物品在数据库中的排序顺位为11，加上日期以及图片格式，生成诸如20130401_1_0001_1.jpg的文件名
    public static String getPirtureName(String typeCode, Date date,int num,String picType){
        SimpleDateFormat yyyymmdd = new SimpleDateFormat("yyyyMMdd");
        String first = yyyymmdd.format(date);
        String second = "_"+typeCode.substring(3,4)+"_"+typeCode.substring(4,8)+"_";
        return first+second+num+"."+picType;
    }


    //根据保存的文件名，以及最终保存的路径，创建File对象方便上层调用
    public static File saveFile(String saveName){
        File file = new File(ClassLoader.getSystemResource("static/client/images/product").getPath(), saveName);
        return file;
    }
    
    //创建轮播图上传的图片名字
    public static String getPicNameByTime(String picType) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
		String newDate=sdf.format(new Date());	
		return newDate+"."+picType;
    }
}
