package org.zhku.eshop.service.client.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.entity.EUser;
import org.zhku.eshop.mapper.EUserMapper;
import org.zhku.eshop.service.client.ClientUserService;

import java.util.Date;
import java.util.List;

@Service
public class ClientUserServiceImpl implements ClientUserService {

    @Autowired(required = false)
    EUserMapper eUserMapper;


	@Override
	public int addUser(EUser user) {
		return eUserMapper.insert(user);
	}

	@Override
	public void deleteUsers(List<Integer> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EUser checkUserbyMail(String loginId, String password) {
		EUser user = eUserMapper.selectByEmailAndPwd(loginId,password);
		return user;
	}

	@Override
	public EUser checkUserbyUserID(String loginId, String password) {
		EUser user = eUserMapper.selectByUserIdAndPwd(loginId,password);
		return user;
	}

	@Override
	public EUser checkUserbyPhone(String loginId, String password) {
		EUser user = eUserMapper.selectByPhoneAndPwd(loginId,password);
		return user;
	}

	@Override
	public EUser selectByPrimaryKey(int id) {
		return eUserMapper.selectByPrimaryKey(id);
	}

    

   
    
}
