package org.zhku.eshop.service.client;


import java.util.List;

import org.zhku.eshop.entity.EGoods;
import org.zhku.eshop.entity.EGoodsType;
import org.zhku.eshop.entity.EPictureCarousel;
import org.zhku.eshop.entity.ETimeLimited;
import org.zhku.eshop.entity.EUser;
/**
 * 负责首页的业务处理
 * @author Administrator
 *
 */
public interface ClientIndexService {

	public List<EPictureCarousel> selectPictureCarousel();

	
}
