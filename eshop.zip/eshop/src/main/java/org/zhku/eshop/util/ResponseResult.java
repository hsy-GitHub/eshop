package org.zhku.eshop.util;

import java.util.List;

public class ResponseResult<T> {
    private List<T>list;
    private int total;

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public ResponseResult(List<T> list, int total) {
        this.list = list;
        this.total = total;
    }
}
