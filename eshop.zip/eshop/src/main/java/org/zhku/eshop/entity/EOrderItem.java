package org.zhku.eshop.entity;

public class EOrderItem extends EOrderItemKey {
    private Integer orderNum;

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }
}