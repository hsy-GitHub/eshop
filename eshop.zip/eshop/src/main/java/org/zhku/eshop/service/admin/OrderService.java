package org.zhku.eshop.service.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.zhku.eshop.util.ResponseResult;
import org.zhku.eshop.entity.EOrder;
import org.zhku.eshop.entity.EOrderDetail;
import org.zhku.eshop.mapper.EOrderMapper;

import java.util.Date;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    EOrderMapper mapper;

    public List<EOrder>getOrdersByUserIdPageable(int userId,int pageNum,int pageSize){
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        return mapper.selectByUserIdPageable(userId,start,pageSize);
    }

    public boolean sent(int order_id){
        EOrder eOrder = mapper.selectByPrimaryKey(order_id);
        if(eOrder.getTradingStatus()==null){
            eOrder.setTradingStatus(0);
            eOrder.setSendDate(new Date());
            mapper.updateByPrimaryKey(eOrder);
            return true;
        }
        return false;
    }

    public ResponseResult<EOrderDetail> getOrderNeededSent(int pageNum, int pageSize,String username){
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        List<EOrderDetail> list = mapper.selectByTradingStatus(null, start, pageSize,username);
        int total = mapper.countByTradingStatus(null,username);
        return new ResponseResult<>(list,total);
    }

    public ResponseResult<EOrderDetail> getOrderInTransporting(int pageNum, int pageSize,String username){
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        List<EOrderDetail> list = mapper.selectByTradingStatus("0", start, pageSize,username);
        int total = mapper.countByTradingStatus("0",username);
        return new ResponseResult<>(list,total);
    }

    public ResponseResult<EOrderDetail> getOrderCompleted(int pageNum, int pageSize,String username){
        int start = pageNum<1?0:(pageNum-1)*pageSize;
        List<EOrderDetail> list = mapper.selectByTradingStatus("1", start, pageSize,username);
        int total = mapper.countByTradingStatus("1",username);
        return new ResponseResult<>(list,total);
    }
}
